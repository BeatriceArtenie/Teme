function [Ix, Iy, Ixy] = precalc_d(I)
    % =========================================================================
    % Prealculeaza matricile Ix, Iy si Ixy ce contin derivatele dx, dy, dxy ale 
    % imaginii I pentru fiecare pixel al acesteia
    % =========================================================================
    
    % obtine dimensiunea imaginii
    [m n nr_colors] = size(I);
    
    % TODO: fa cast matricii I la double

    % TODO: calculeaza matricea cu derivate fata de x Ix

    % TODO: calculeaza matricea cu derivate fata de y Iy

    % TODO: calculeaza matricea cu derivate fata de xy Ixy

endfunction
