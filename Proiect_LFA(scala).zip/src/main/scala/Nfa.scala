import Nfa.void

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, Stack}
import scala.util.control.Breaks.break

class Transition[A](start: A, end: A, char: Char, isEps :Boolean) {
  def getStart: A = return start;
  def getEnd: A = return end;
  def getEps: Boolean = return isEps;
  def getChar: Char = {
    if(isEps == true)
      return '_'
    else
      return char
  }

  override def toString: String = {
    val outString = "(" + start + ", " + end + ", " + char + ", " + isEps + ")"
    outString
  }
}


class Nfa[A](stari: Set[A], tranzitii: Set[Transition[A]], start:A, end:Set[A]) {
  // The following methods are only the methods directly called by the test suite. You can (and should) define more.

  def getTransitions: Set[Transition[A]] = tranzitii;

  def getStart: A = start;

  def getEndStates: Set[A] = end;

  def map[B](f: A => B) : Nfa[B] = {
    def transformers (transitie : Transition[A]) : Transition[B] = {
      val nStart = f(transitie.getStart)
      val nEnd = f(transitie.getEnd)
      new Transition(nStart, nEnd, transitie.getChar, transitie.getEps);
    }
    var newStari = stari.map(f);
    var newTranzitii = tranzitii.map(x => transformers(x))
    var newStart = f(start);
    var newEnd =end.map(f);
    var newNfa = new Nfa[B](newStari, newTranzitii, newStart, newEnd);
    newNfa;
  }
  // TODO implement map

  def next(state:A, c: Char): Set[A] = {
    var nextStates: Set[A] = Set()
    for(tranz <- tranzitii) {
      if(tranz.getStart.equals(state) && tranz.getChar.equals(c)) {
        if(nextStates.equals(Set()))
          nextStates = Set(tranz.getEnd)
        else
          nextStates = nextStates ++ Set(tranz.getEnd)
      }
    }
    nextStates
  } // TODO implement next

  def accepts(str: String): Boolean = {
    var initialTuple = (start, str)
    //if(str == null && actualState == end) return true
    var tuplesConf : Set[(A, String)] = Set(initialTuple)
    def aux (tuple: (A, String)) : Set[(A, String)] = {
      var nextStates: Set[A] = Set()
      if(tuple._2 == ""){
        nextStates = next(tuple._1,  " ".charAt(0))
      }
      else {
        nextStates = next(tuple._1, tuple._2.apply(0))
        println(tuple._2.apply(0))
      }
      var nextTuples : Set[(A, String)] = Set()
      for (i <- nextStates) {
        if(nextTuples.equals(Set()))
          nextTuples = Set((i, tuple._2.drop(1)))
        else
          nextTuples = nextTuples ++ Set((i, tuple._2.substring(1)))
      }
      return nextTuples
    }

    def isConfFinal(conf: Set[(A, String)]): Boolean = {
      for(tuple <- conf) {
        if(tuple._2.equals("") && isFinal(tuple._1))
          return true
      }
      false
    }
    var prevConf = Set((start, "vgceshvfg"))

    var stop = false

    while(!prevConf.equals(tuplesConf) && !stop) {
      prevConf = tuplesConf
      for(conf <- tuplesConf){
        var moreTuples: Set[(A, String)] = Set()
        if(conf._2.nonEmpty) {
          moreTuples = aux(conf)
        }
        var moreEpsTuples = getEpsTranz(conf)
        tuplesConf ++= moreTuples
        tuplesConf ++= moreEpsTuples
      }
      if(isConfFinal(tuplesConf))
        stop = true
    }
    if(isConfFinal(tuplesConf)) {
     return true
    }
    false
  } // TODO implement accepts

  def getStates : Set[A] = stari // TODO implement getStates

  def isFinal(state: A): Boolean = {
    for(finals <- end) {
      if(state.equals(finals))
        return true
    }
    false
  }  // TODO implement isFinal

  def noOfStates(stari: Set[A]): Int = {
    var contor = 0;
    for(i <- 0 until stari.size) {
      contor = contor + 1;
    }
    return contor;
  }

  def getEpsTranz(tuple: (A, String)): Set[(A, String)] = {
    var nextStates = next(tuple._1, '_')
    var nextTuples : Set[(A, String)] = Set()

    if(nextStates.nonEmpty) {
      for (i <- nextStates) {
        nextTuples = nextTuples ++ Set((i, tuple._2))
      }
    }

   return nextTuples
  }
}



// This is a companion object to the Nfa class. This allows us to call the method fromPrenex without instantiating the Nfa class beforehand.
// You can think of the methods of this object like static methods of the Nfa class
object Nfa {

  def void(str: String) : Nfa[Int] = {
    val stari = Set(0, 1);
    val start = 0;
    val end = Set(1);
    //val tranz = Set();
    val nfa = new Nfa[Int](stari, Set(), start, end);
    return nfa;
  }

  def epsilon(str: String) : Nfa[Int] = {
    val stari = Set(0);
    val start = 0;
    val end = Set(0);
    //val tranz = Set();
    val nfa = new Nfa[Int](stari, Set(), start, end);
    return nfa;
  }

  def charact(character:Char) : Nfa[Int] = {
    val stari = Set(0, 1);
    val tranz = Set(new Transition[Int](0, 1, character, false));
    val start = 0;
    val end = Set(1);
    //val tranz = Set();
    val nfa = new Nfa[Int](stari, tranz, start, end);
    return nfa;
  }
  def concat(nfa1: Nfa[Int], nfa2 : Nfa[Int]): Nfa[Int] = {
    var updateNfa2 = nfa2.map(x => x + nfa1.noOfStates(nfa1.getStates));
    var stari = nfa1.getStates ++ updateNfa2.getStates;

    var tranz = nfa1.getTransitions ++ updateNfa2.getTransitions;
    var epsTranz = new Transition[Int](nfa1.getEndStates.last, updateNfa2.getStart, '_', true);
    tranz += epsTranz;
    new Nfa[Int](stari, tranz, nfa1.getStart, updateNfa2.getEndStates);
  }

  def union(nfa1: Nfa[Int], nfa2 : Nfa[Int]): Nfa[Int] = {

   var stari = Set(0);
    var updateNfa1 = nfa1.map(x => x + 1)
    var updateNfa2 = nfa2.map(x => x + updateNfa1.noOfStates(updateNfa1.getStates) + 1)
    stari ++= updateNfa1.getStates ++ updateNfa2.getStates
    stari += stari.size
    println("Stari: " + stari)
    var endState = Set(stari.size - 1)
    var tranz = Set(new Transition[Int](0, updateNfa1.getStart, '_',true));
    tranz += new Transition[Int](0, updateNfa2.getStart, '_',true)
    tranz ++= updateNfa1.getTransitions ++ updateNfa2.getTransitions;
    tranz += new Transition[Int](updateNfa1.getEndStates.head, endState.head, '_', true)
    tranz += new Transition[Int](updateNfa2.getEndStates.head, endState.head, '_', true)
    new Nfa[Int](stari, tranz, 0, endState);
  }

  def star(nfa1: Nfa[Int]): Nfa[Int] = {
    var stari = Set(0);
    var updateNfa = nfa1.map(x => x + 1);
    stari ++= updateNfa.getStates;
    stari += stari.size;
    var endStatePos = Set(stari.size - 1);
    var tranz = Set(new Transition [Int](0, updateNfa.getStart, '_', true))
    tranz ++= updateNfa.getTransitions
    tranz += new Transition[Int](updateNfa.getEndStates.head, endStatePos.head, '_', true)
    tranz += new Transition[Int](updateNfa.getEndStates.head, updateNfa.getStart, '_', true)
    tranz += new Transition[Int](0, endStatePos.head, '_', true)
    return new Nfa[Int](stari, tranz, 0, endStatePos);
  }

  def plus(nfa1: Nfa[Int]): Nfa[Int] = {
    concat(nfa1, star(nfa1))
  }

  def maybe(nfa1: Nfa[Int]): Nfa[Int] = {
    union(nfa1, epsilon(""))
  }


  def fromPrenex(str: String): Nfa[Int] = { // TODO implement Prenex -> Nfa transformation.
     var parseStack = new mutable.Stack[Nfa[Int]]();
    //if(str.contains(""))
     var parsedStr = str.split(" ").reverse;


    for(i <- Range(0, parsedStr.length)) {
      //println(parsedStr.apply(i))
      if(parsedStr.apply(i).length == 1)
        parseStack = parseStack.push(charact(parsedStr.apply(i).head))
      else if(parsedStr.apply(i).length == 3) {
        println(parsedStr.apply(i))
        if(parsedStr.apply(i).contains('\'')) {
          println("Special")
          var parseSpecial = parsedStr.apply(i).split('\'')
          //println(parseSpecial)
          println(parseSpecial.mkString("Array(", ", ", ")"))
          if(parseSpecial.nonEmpty)
            println("I extracted: " + parseSpecial.last.head)
          if(parseSpecial.nonEmpty)
            parseStack = parseStack.push(charact(parseSpecial.last.head))
          else
            parseStack = parseStack.push(charact('\''))
        }
        else {
          parseStack = parseStack.push(epsilon(parsedStr(i)))
        }
      }
      else if(parsedStr.apply(i).contentEquals("void"))
        parseStack = parseStack.push(void(parsedStr(i)))
      else if(parsedStr.apply(i).contentEquals("STAR")){
        var prevNfa = parseStack.pop()
        parseStack = parseStack.push(star(prevNfa))
      }
      else if(parsedStr.apply(i).contentEquals("CONCAT")){
        var prevNfa1 = parseStack.pop()
        var prevNfa2 = parseStack.pop()
        parseStack = parseStack.push(concat(prevNfa1, prevNfa2))
      }
      else if(parsedStr.apply(i).contentEquals("UNION")){
        var prevNfa1 = parseStack.pop()
        var prevNfa2 = parseStack.pop()
        parseStack = parseStack.push(union(prevNfa1, prevNfa2))
      }
    }
    val res = parseStack.pop()
    //println(res.getTransitions)
    res
  }

  // You can add more methods to this object
}