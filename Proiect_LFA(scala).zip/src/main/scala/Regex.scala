import scala.collection.mutable

object Regex {
  /*
    This function should:
    -> Classify input as either character(or string) or operator
    -> Convert special inputs like [0-9] to their correct form
    -> Convert escaped characters
  */

  // tipuri stiva
  trait Prenex {}

  case class CompletedPrenex(string: String) extends Prenex {
    override def toString: String = if(string == " ") "' '" else string
  }

  // UNION ? ?
  case class UNIONEmpty(string: String) extends Prenex{
    override def toString: String = string
  }

  // UNION el ?
  case class UNION1(string: String, elem: String) extends Prenex{
    override def toString: String = string + " " + elem
  }

  // CONCAT ? ?
  case class CONCATEmpty(string: String) extends Prenex{
    override def toString: String = string
  }

  // CONCAT el ?
  case class CONCAT1(string: String, elem: String) extends Prenex{
    override def toString: String = string + " " + elem
  }

  // STAR ?
  case class STAREmpty(string: String) extends Prenex{
    override def toString: String = string
  }

  def whatprocess(s:List[Char]): List[Either[Char, Char]] = {

    if(s.size == 1)
      return List(Right(s.head))
    else if(s.size == 3) {
      return List(Left('e'), Left('p'), Left('s'))
    } else if(s.size == 5) {

      var list: List[Either[Char, Char]] = List(Left('('))

      if(s.apply(1).equals('0')) {
        for(i <- Range(0, 9))
          list ++= List(Right((i + '0').toChar)) ++ List(Left('|'))
        list ++= List(Right((9 + '0').toChar)) ++ List(Left(')'))
      } else if(s.apply(1).equals('a')){
        for(i <- Range('a', 'z'))
          list ++= List(Right(i.toChar)) ++ List(Left('|'))
        list ++= List(Right('z')) ++ List(Left(')'))
      } else {
        for(i <- Range('A', 'Z'))
          list ++= List(Right(i.toChar)) ++ List(Left('|'))
        list ++= List(Right('Z')) ++ List(Left(')'))
      }
      return list
    } else {
      List[Either[Char, Char]]()
    }
    List[Either[Char, Char]]()
  }
  def preprocess(s:List[Char]): List[Either[Char,Char]] = {

    // Set de caractere care nu necesita prelucrare:
    var simpleChars: Set[Char] = Set()
    for(i <- Range(0, 10))
      simpleChars += (i + '0').toChar
    for(i <- Range('a', 'z'))
      simpleChars += i.toChar
    simpleChars += 'z'
    for(i <- Range('A', 'Z'))
      simpleChars += i.toChar
    simpleChars ++= Set('Z')

    def questionMark(l: List[Either[Char, Char]]): List[Either[Char, Char]] = {
      List(Left('(')) ++ List(Left('(')) ++ l ++ List(Left(')')) ++ List(Left('|'), Left('e'), Left('p'), Left('s'), Left(')'))
    }

    def oneOrMore(l: List[Either[Char, Char]]): List[Either[Char, Char]] = {
      List(Left('(')) ++ List(Left('(')) ++ l ++ List(Left(')')) ++ List(Left('(')) ++ l ++ List(Left(')')) ++ List(Left('*'), Left(')'))
    }

    def partialRes(s: List[Char]): List[Either[Char, Char]] = {
      var sCopy:List[Char] = List()
      sCopy ++= s
      var partResult: List[Either[Char, Char]] = List()
      //println(sCopy.toString())
      while(sCopy.nonEmpty) {

        var i = 0
        var dropping = 0
        var currentChar = sCopy.apply(i)


        if (simpleChars.contains(currentChar) && !currentChar.equals('e')) {

          var regex = List(Right(currentChar))
          if(i < sCopy.size - 1) {
            if (sCopy(i + 1) == '+') {
              partResult ++= oneOrMore(regex)
              dropping = 2
            } else if (sCopy(i + 1) == '?') {
              partResult ++= questionMark(regex)
              dropping = 2
            } else {
              partResult ++= regex
              dropping = 1
            }
          } else {
            partResult ++= regex
            dropping = 1
          }
          dropping = 1
        } else if(currentChar.equals('|') || currentChar.equals('*')) {
          partResult ++= List(Left(currentChar))
          dropping = 1
        } else if (currentChar.equals('e')) {

          if(sCopy.length >= 3) {
            if(sCopy.apply(1).equals('p') && sCopy.apply(2).equals('s')) {
              partResult ++= List(Left('e')) ++ List(Left('p')) ++ List(Left('s'))
              dropping = 3
            } else {
              partResult ++= List(Right('e'))
              dropping = 1
            }
          } else {
            partResult ++= List(Right('e'))
            dropping = 1
          }
          //dropping = 1
        } else if (currentChar == '[') {

          var regex = whatprocess(List(currentChar, sCopy(i + 1), sCopy(i + 2), sCopy(i + 3), sCopy(i + 4)))
          if(i + 5 < sCopy.size) {
            if(sCopy(i + 5) == '+') {
              partResult ++= oneOrMore(regex)
              dropping = 6
            } else if(sCopy(i + 5) == '?') {
              partResult ++= questionMark(regex)
              dropping = 6
            } else {
              partResult ++= regex
              dropping = 5
            }
          } else {
            partResult ++= regex
            dropping = 5
          }
        } else if(currentChar == ')') {
          partResult ++= List(Left(')'))
        } else if(currentChar == '(') {

          // ia textul din cea mai mare pereche de paranteze
          sCopy = sCopy.drop(1)
          var partList: List[Char] = List()
          while((sCopy.count(c => c.equals('(')) != sCopy.count(c => c.equals(')'))) && sCopy.nonEmpty) {
            partList ++= List[Char](sCopy.head)
            sCopy = sCopy.drop(1)
          }

          partList = partList.dropRight(1) // scapa de paranteza inchisa de la final
          var partListRegex = partialRes(partList)

          if(sCopy.nonEmpty) {
            if(sCopy.head.equals('+')) {
              partResult ++= oneOrMore(partListRegex)
              dropping = 1
            } else if (sCopy.head.equals('?')) {
              partResult ++= questionMark(partListRegex)
              dropping = 1
            } else {
              partResult ++= List(Left('(')) ++ partListRegex ++ List(Left(')'))
              dropping = 0
            }
          } else {
            partResult ++= List(Left('(')) ++ partListRegex ++ List(Left(')'))
            dropping = 0
          }

        } else if (currentChar.equals('\'')) {
          partResult = partResult ++ List(Right(sCopy.apply(1)))
          dropping = 3
        } else {
          dropping = 1
        }
        sCopy = sCopy.drop(dropping)
      }
      partResult
    }
    partialRes(s)
  }

  def changeSTAR(stack: mutable.Stack[Prenex]): mutable.Stack[Prenex] = {
    var newStack: mutable.Stack[Prenex] = mutable.Stack()
    var stackCopy = stack
    if(stack.size < 2)
      return stack
    while(stackCopy.nonEmpty){
      stackCopy.head match {
        case STAREmpty(x) => {
          stackCopy = stackCopy.drop(1)
          stackCopy.head match {
            case CompletedPrenex(x) => {
              val complete = "STAR" + " " + x
              newStack = newStack.push(CompletedPrenex(complete))
              stackCopy = stackCopy.drop(1)
            }
            case default => {
              newStack = newStack.push(STAREmpty("STAR"))
              newStack = newStack.push(stackCopy.head)
              stackCopy = stackCopy.drop(1)
            }
          }
        }
        case default => {
          newStack = newStack.push(stackCopy.head)
          stackCopy = stackCopy.drop(1)
        }
      }
    }
    newStack
  }

  def changeConcat(stack: mutable.Stack[Prenex]): mutable.Stack[Prenex] = {
    var newStack: mutable.Stack[Prenex] = mutable.Stack()
    var stackCopy = stack
    var foundConcat = false

    while(stackCopy.nonEmpty && !foundConcat) {
      //println("1: " + stackCopy + newStack)
      stackCopy.head match {
        case CompletedPrenex(x) => {
          stackCopy = stackCopy.drop(1)
          //println("2: " + stackCopy + newStack)
          if (stackCopy.nonEmpty) {
            stackCopy.head match {
              case CompletedPrenex(y) => {
                val complete = "CONCAT " + x + " " + y
                newStack = newStack.push(CompletedPrenex(complete))
                foundConcat = true
                stackCopy = stackCopy.drop(1)
              }
              case default => {
                newStack = newStack.push(CompletedPrenex(x))
                //newStack = newStack.push(stackCopy.head)
                //stackCopy = stackCopy.drop(1)
              }
            }
          } else { //stackCopy e empty
            newStack = newStack.push(CompletedPrenex(x))
          }
        }
        case default => {
          //println("3: " + stackCopy + newStack)
          newStack = newStack.push(default)
          stackCopy = stackCopy.drop(1)
        }
      }
    }

    if(foundConcat && stackCopy.nonEmpty) {
      newStack.pushAll(stackCopy)
    }

    newStack.reverse
  }

  def changeUnion(stack: mutable.Stack[Prenex]): mutable.Stack[Prenex] = {
    var newStack: mutable.Stack[Prenex] = mutable.Stack()
    var stackCopy = stack
    var foundUnion = false

    while(stackCopy.nonEmpty && !foundUnion) {
      stackCopy.head match {
        case UNION1(x, el) => {
          stackCopy = stackCopy.drop(1)
          if (stackCopy.nonEmpty) {
            val el2 = stackCopy.head
            stackCopy = stackCopy.drop(1)
            el2 match {
              case CompletedPrenex(y) => {
                newStack = newStack.push(CompletedPrenex("UNION " + el + " " + y))
                foundUnion = true
              }
              case default => {
                newStack = newStack.push(el2)
                newStack = newStack.push(UNION1(x, el))
                stackCopy.drop(1)
              }
            }
          }
        }
        case CompletedPrenex(x) => {
          stackCopy = stackCopy.drop(1)
          if(stackCopy.nonEmpty) {
            val el2 = stackCopy.head
            stackCopy = stackCopy.drop(1)
            el2 match {
              case UNIONEmpty(y) => {
                newStack = newStack.push(UNION1("UNION", x))
                foundUnion = true
              }
              case default => {
                newStack = newStack.push(el2)
                newStack = newStack.push(UNIONEmpty("UNION"))
                stackCopy = stackCopy.drop(1)
              }
            }
          } else {
            newStack = newStack.push(CompletedPrenex(x))
          }
        }
        case default => {
          newStack = newStack.push(stackCopy.head)
          stackCopy = stackCopy.drop(1)
        }
      }
    }
    if(foundUnion && stackCopy.nonEmpty)
      newStack.pushAll(stackCopy)
    newStack
  }

  def completeStack(stack: mutable.Stack[Prenex]): mutable.Stack[Prenex] = {
    // aici procesezi stackul 1 pas
    var newStack: mutable.Stack[Prenex] = mutable.Stack()
    //println("star problem")
    //println("1" + stack)
    newStack = changeSTAR(stack.clone())
    //println(newStack)
    // println("star no problem")
    var doneWithConcats = false
    while(!doneWithConcats) {
      var copy = newStack.clone()
      newStack = changeConcat(newStack.clone())
      if(copy.equals(newStack))
        doneWithConcats = true
    }
    println("preunion" + newStack)
    //println("concat no problem")
    newStack = changeUnion(newStack.clone())
    println("post" + newStack)
    newStack
  }

  // This function should construct a prenex expression out of a normal one.
  def toPrenex(str: String): String = {
    var strList = str.toList
    var strPreProccesed = preprocess(strList)
    //println(strPreProccesed.toString())
    var stack: mutable.Stack[Prenex] = mutable.Stack()

    println(strPreProccesed)

    while(strPreProccesed.nonEmpty) {
      strPreProccesed.head match {
        case Right(x) => {
          stack = stack.push(CompletedPrenex(x.toString))
          strPreProccesed = strPreProccesed.drop(1)
        }
        case Left(x) => {
          if(x.equals('*')) {
            stack = stack.push(STAREmpty("STAR"))
            strPreProccesed = strPreProccesed.drop(1)
          } else if (x.equals('|')) {
            stack = stack.push(UNIONEmpty("UNION"))
            strPreProccesed = strPreProccesed.drop(1)
          } else if (x.equals('e')) {
            stack = stack.push(CompletedPrenex("eps"))
            strPreProccesed = strPreProccesed.drop(3)
          } else if (x.equals('(')) { // cazul '(' a ramas
            var partList: String = ""
            strPreProccesed = strPreProccesed.drop(1)
            while((strPreProccesed.count(c => c.equals(Left('('))) != strPreProccesed.count(c => c.equals(Left(')')))) && strPreProccesed.nonEmpty) {
              strPreProccesed.head match {
                case Right(x) => partList = partList + x
                case Left(x) => partList = partList + x
              }
              strPreProccesed = strPreProccesed.drop(1)
            }
            partList = partList.dropRight(1)
            //println("Going recursive for: " + partList)
            stack = stack.push(CompletedPrenex(toPrenex(partList)))
          } else {
            strPreProccesed = strPreProccesed.drop(1)
          }
        }
      }
    }

    var stackCopy = stack
    //println("Stack:")
    //println(stack.toString())
    //println("Stack head: " + stack.head)
    do {
      stackCopy = stack
      stack = completeStack(stack.clone())
      //println(stack.toString())
    } while(!stackCopy.equals(stack))

    val res = stack.pop().toString
    //println(res)
    res
  }
}
