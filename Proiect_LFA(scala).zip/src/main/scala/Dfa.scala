import scala.util.control.Breaks.break

class TransitionDFA[A](start: A, end: A, char: Char) {
  def getStart: A = return start;

  def getEnd: A = return end;

  def getChar: Char = char

  override def toString: String = {
    val outString = "(" + start + ", " + end + ", " + char + ")"
    outString
  }
}

class Dfa[A](stari: Set[A], tranzitii: Set[TransitionDFA[A]], start: A, end: Set[A], nfa: Nfa[A]) {

  def getTransitions: Set[TransitionDFA[A]] = tranzitii;

  def getStart: A = start;

  def getEndStates: Set[A] = end;

  def getNfa: Nfa[A] = nfa;

  def printDFA: Unit = {
    println("Stari: " + stari)
    println("Tranzitii: ")
    for(tr <- tranzitii)
      println(" Din " + tr.getStart + " in " + tr.getEnd + " pe caracterul " + tr.getChar)
    println("Start: " + start)
    println("End: " + end)

  }

  // The following methods are only the methods directly called by the test suite. You can (and should) define more.

  def map[B](f: A => B): Dfa[B] = {
    def transformers (transitie : TransitionDFA[A]) : TransitionDFA[B] = {
      val nStart = f(transitie.getStart)
      val nEnd = f(transitie.getEnd)
      new TransitionDFA(nStart, nEnd, transitie.getChar);
    }
    var newStari = stari.map(f);
    //var newStari:Set[B] = Set()
    var newTranzitii = tranzitii.map(x => transformers(x))
    var newStart = f(start);
    var newEnd = end.map(f);
    var newDfa = new Dfa[B](newStari, newTranzitii, newStart, newEnd, null);
    newDfa;
  } // TODO implement map

  def next(state: A, c: Char): A = {
    var nextState: A = state
    for(tranz <- tranzitii) {
      if(tranz.getStart.equals(state) && tranz.getChar.equals(c)) {
        nextState =  tranz.getEnd
      }
    }
    nextState
  } // TODO implement next

  def accepts(str: String): Boolean =  // TODO implement accepts
  {
    def myaux(str: String): Boolean = {
      var initialTuple = (start, str)
      //if(str == null && actualState == end) return true
      var tuplesConf: Set[(A, String)] = Set(initialTuple)

      def aux(tuple: (A, String)): Set[(A, String)] = {
        var nextStates: Set[A] = Set()
        if (tuple._2 == "") {
          //var charact: Char = " ".charAt(0)
          nextStates = nfa.next(tuple._1, " ".charAt(0))
        }
        else {
          nextStates = nfa.next(tuple._1, tuple._2.apply(0))
         // println(tuple._2.apply(0))
        }
        var nextTuples: Set[(A, String)] = Set()
        for (i <- nextStates) {
          if (nextTuples.equals(Set()))
            nextTuples = Set((i, tuple._2.drop(1)))
          else
            nextTuples = nextTuples ++ Set((i, tuple._2.substring(1)))
        }
        return nextTuples
      }

      def isConfFinal(conf: Set[(A, String)]): Boolean = {
        for (tuple <- conf) {
          if (tuple._2.equals("") && isFinal(tuple._1))
            return true
        }
        false
      }

      var prevConf = Set((start, "vgceshvfg"))
      //var prevConf: Set[(A, String)] = Set()
      var stop = false
      //var conf : Set[(A, String)] = Set(initialTuple)
      while (!prevConf.equals(tuplesConf) && !stop) {
        prevConf = tuplesConf
        for (conf <- tuplesConf) {
          var moreTuples: Set[(A, String)] = Set()
          if (conf._2.nonEmpty) {
            moreTuples = aux(conf)
          }
          var moreEpsTuples = nfa.getEpsTranz(conf)
          tuplesConf ++= moreTuples
          tuplesConf ++= moreEpsTuples
        }
        if (isConfFinal(tuplesConf))
          stop = true
      }
      if (isConfFinal(tuplesConf)) {
        return true
      }
      false
    }
    //myaux(str)
    nfa.accepts(str)
//    val initialTuple = (start, str)
//    //if(str == null && actualState == end) return true
//    var tuplesConf : Set[(A, String)] = Set(initialTuple)
//    def aux (tuple: (A, String)) : Set[(A, String)] = {
//      var nextStates: A = tuple._1
//      if(tuple._2 == ""){
//        nextStates = next(tuple._1,  " ".charAt(0))
//      }
//      else {
//        nextStates = next(tuple._1, tuple._2.apply(0))
//        println(tuple._2.apply(0))
//      }
//      var nextTuples : Set[(A, String)] = Set()
//      if(nextTuples.equals(Set()))
//        nextTuples = Set((nextStates, tuple._2.drop(1)))
//      else
//        nextTuples = nextTuples ++ Set((nextStates, tuple._2.substring(1)))
//      nextTuples
//    }
//
//    def isConfFinal(conf: Set[(A, String)]): Boolean = {
//      for(tuple <- conf) {
//        if(tuple._2.equals("") && isFinal(tuple._1))
//          return true
//      }
//      false
//    }
//    var prevConf = Set((start, "vgceshvfg"))
//    //var prevConf: Set[(A, String)] = Set()
//    var stop = false
//    //var conf : Set[(A, String)] = Set(initialTuple)
//    while(!prevConf.equals(tuplesConf) && !stop) {
//      prevConf = tuplesConf
//      for(conf <- tuplesConf){
//        var moreTuples: Set[(A, String)] = Set()
//        if(conf._2.nonEmpty) {
//          moreTuples = aux(conf)
//        }
//        tuplesConf ++= moreTuples
//      }
//      if(isConfFinal(tuplesConf))
//        stop = true
//    }
//    if(isConfFinal(tuplesConf)) {
//      return true
//    }
//    false
  }
  def getStates: Set[A] = stari // TODO implement getStates

  def isFinal(state: A): Boolean = {
    if (end.contains(state))
      return true
    false
  } // TODO implement isFinal


}

// This is a companion object to the Dfa class. This allows us to call the method fromPrenex without instantiating the Dfa class beforehand.
// You can think of the methods of this object like static methods of the Dfa class
object Dfa {

  def epsClosures(state: Int, nfa: Nfa[Int]): Set[Int] = {
    var transitionsCopy = nfa.getTransitions
    var closure: Set[Int] = Set(state)
    var checkedClosures: Set[Int] = Set()
    while(closure.nonEmpty) {
      for (state <- closure) {
        for (t <- transitionsCopy) {
          if (t.getStart == state && t.getEps) {
            closure += t.getEnd
            transitionsCopy -= t
          }
        }
        checkedClosures += state
        closure -= state
      }

    }

    checkedClosures
  }

  def encode(stari: Set[Int]): Int = {
    var arr = stari.toArray
    arr.sorted
    for(i <- arr.indices)
      arr(i) = arr(i) + 10
    //println("New array: " + arr.mkString("Array(", ", ", ")"))
    var cod = 0
    var i = 0
    for(el <- arr) {
      cod += el * (Math.pow(100, arr.size - i - 1)).toInt
      i += 1
    }
    //println("true code: " + cod)

    return cod
  }

  def decode(cod: Int): Set[Int] = {
    var initStates: Set[Int] = Set()
    var auxCod = cod
    while(auxCod > 0) {
      var aux = (auxCod % 100 - 10)
      //println(auxCod)
      initStates += aux
      auxCod = auxCod / 100
    }
    initStates
  }
  def statesSets(eClosures: Set[Set[Int]], nfa: Nfa[Int]): Set[(Set[Int], TransitionDFA[Int])] = {
    //var startSet: Set[Int] = Set()
    val startSet = (eClosures.filter(_.contains(0))).head
   // println("Start set: " + startSet)

    var allSetStates: Set[Set[Int]] = Set(startSet)
    var checkedStatesSet: Set[Set[Int]] = Set()
    var checkedTransitions: Set[TransitionDFA[Int]] = Set()
    var result: Set[(Set[Int], TransitionDFA[Int])] = Set()
    while (allSetStates.nonEmpty) {
      //println("1")
      for (set <- allSetStates) {
        //println("2")
        val alphabet = Set('a', 'b', 'c', 'd', '$', '@', '*', ' ', '{', '(', '\n', '\r', '\'', '\"')
        for (character <- alphabet) {
          //println("3")
          var newSet: Set[Int] = Set()
          for (state <- set) {
            //println("4")
            var nextStates = nfa.next(state, character)
            if (nextStates.nonEmpty)
              newSet ++= nextStates
          }
          var newStateSet: Set[Int] = Set()
          for (s <- newSet) {
            //println("5")
            newStateSet ++= epsClosures(s, nfa)
          }
          var newTranz =  new TransitionDFA[Int](encode(set), encode(newStateSet), character)
          if (newStateSet.nonEmpty && !checkedStatesSet.contains(newStateSet)) {
            //result = result ++ Set((newStateSet, newTranz))
            //println("Actually added transition: " + newTranz)
            //println("New state set: " + newStateSet)
            allSetStates += newStateSet
          }
          if(newStateSet.nonEmpty && !checkedTransitions.contains(newTranz)) {
            result = result ++ Set((newStateSet, newTranz))
            checkedTransitions += newTranz
          }
          //println("New possible transition: " + new TransitionDFA[Int](encode(set), encode(newStateSet), character))
        }
        checkedStatesSet += set
        allSetStates -= set
      }
      //println("allSS = " + allSetStates)
     // println("checked = " + checkedStatesSet)
    }
    //checkedStatesSet
    result
  }

  def findFinalStates(stateSets: Set[Set[Int]], nfaFinals: Set[Int]): Set[Int] = {
    var finals: Set[Int] = Set()
    for(nfaFState <- nfaFinals) {
      for(stateSet <- stateSets) {
        if(stateSet.contains(nfaFState))
          finals += encode(stateSet)
      }
    }
    finals
  }

  def fromPrenex(str: String): Dfa[Int] = // TODO implement Prenex -> Dfa transformation. hint: you should make use of Nfa.fromPrenex to build the Dfa
  {
//    println("//////////////////////// TESTE /////////////////////////////////////")
//    for(i <- Range('a', 'y'))
//      println(i.toChar + " ")
//    println()
//    println("////////////////////////////////////////////////////////////////////")
    // Splitting strings test:
//    var str = "CONCAT 'a' 'b'"
//    var parsed = str.split("\' \'")
//    println(parsed.mkString("Array(", ", ", ")"))
//    var words:Set[String] = Set()
    /*for(el <- parsed) {
      if(el.equals(" "))
        words ++= Set(" ")
      else
        words ++= el.split(" ")
    }
    println("Te rog sa mergi: " + words)*/
    /*var testString = "'a'"
    println(testString)
    //testString = "\'a\'"
    println(testString)
    var parsed = testString.split(" ")
    println(parsed.mkString("Array(", ", ", ")"))
    if(parsed.head.contains('\''))
      println(true)
    var parsed2 = parsed.head.split('\'')
    println(parsed.head.split('\'').mkString("Array(", ", ", ")"))
    println(parsed2.head)
    println(parsed2.last)
    var ch = 'i'

    println("Obtained: " + ch)
    */
    var oldNfa = Nfa.fromPrenex(str)
    var eps: Set[Set[Int]] = Set()
    //println("Stari nfa: " + oldNfa.getStates)
   // println("Epsilon Closures:")
    for (state <- oldNfa.getStates) {
      eps += epsClosures(state, oldNfa)
    }
    println(eps)
    var allSets = statesSets(eps, oldNfa)
    //println("I found " + allSets.size + " transitions:")
    //println(allSets)
    var stariEnc: Set[Int] = Set()
    var stariDec: Set[Set[Int]] = Set()
    var tranzitii: Set[TransitionDFA[Int]] = Set()
    var start = encode((eps.filter(_.contains(0))).head)
    var end: Set[Int] = Set()
    for(s <- allSets) {
      tranzitii += s._2
      stariDec += s._1
      stariEnc += encode(s._1)
    }
    stariEnc += start
    stariDec += (eps.filter(_.contains(0))).head
    end = findFinalStates(stariDec, oldNfa.getEndStates)
    var resDfa = new Dfa[Int](stariEnc, tranzitii, start, end, oldNfa)
    //resDfa.printDFA
    resDfa
  }

  // You can add more methods to this object
}
