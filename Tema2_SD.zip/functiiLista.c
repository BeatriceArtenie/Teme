/* ARTENIE Beatrice-Diana - 314CB */
#include <ctype.h>
#include "tlista.h"
#include "TCoada-V.h"
/*--- operatii de baza pentru lista simplu inlantuita ---*/

//Functie ce gaseste pozitia unui serial intr-o lista - primeste adresa listei si numele serialului
int find_pos(TLista *L, char *name)
{
    int poz = 1; //poz va retine pozitia - se initializeaza cu 1
    TLista p = *L; //asociez o variabila p listei L pentru a o parcurge
    InfoSerial *desc; //variabila ce indica descrierea unui serial
    for(; p != NULL; p = p->urm){ //parcurg lista
        desc = ((InfoSerial*)(((AQ)(p->info))->info));
        if(strcmp(desc->nume, name) == 0) // compar numele primit cu numele fiecarui serial
            return poz;
        poz++; //la fiecare iteratie incrementez pozitia
    }
    return 0; //daca nu am gasit serialul in lista, returnez 0
}
int InsCat(TLista* aL, void* ae, FILE *f) //Functie de inserare in categoriile cu id egal cu 1, 2 sau 3; primeste adresa listei in care inserez, informatia ca void * si fisierul de output
{
    TLista aux = malloc(sizeof(TCelula)); //declar si aloc spatiu pentru o noua celula
    aux->info = ae; //plasez informatia in campul info
    InfoSerial *desc = (InfoSerial*)(((AQ)(aux->info))->info); //declar o variabila care va indica descrierea serialului de inserat
    if(find_pos(aL, desc->nume))
        return 0;
    if(*aL == NULL) //daca lista e vida
    {
        aux->urm = NULL; //aux va fi prima celula din lista, deci campul urm nu indica deocamdata catre nimic
        *aL = aux; //inceputul listei devine aux
        fprintf(f, "Serialul %s a fost adaugat la pozitia 1.\n", desc->nume);
        return 1; 
    }
    InfoSerial *desc_curr; //variabila ce indica descrierea serialului curent
    TLista p = *aL, pre = NULL; //p ia adresa primului element din lista, pre este elementul anterior lui p si este initializat cu NULL
    for(; p != NULL; pre = p,  p = p->urm)
    {
        desc_curr = (InfoSerial*)(((AQ)(p->info))->info);
        if(desc_curr->rating < desc->rating) //daca am gasit un serial cu rating mai mic decat cel al serialului de introdus
        {
            if(pre != NULL){ //daca nu inserez la inceputul listei  
            //Refac legaturile:
                aux->urm = p; //campul urm al lui aux ia valoarea lui p
                pre->urm = aux; //campul urm al lui pre ia valoarea lui aux
                fprintf(f, "Serialul %s a fost adaugat la pozitia %d.\n", desc->nume, find_pos(aL, desc->nume));
                return 1;
            }
            if(pre == NULL){ //daca inserez la inceputul listei
                aux->urm = *aL; //campul urm al lui aux ia valoarea lui *aL
                *aL = aux; //inceputul listei devine aux
                fprintf(f, "Serialul %s a fost adaugat la pozitia %d.\n", desc->nume, find_pos(aL, desc->nume));
                return 1;
            }
        }
        if(desc_curr->rating == desc->rating) //daca am intalnit un serial cu acelasi rating
        {
                
                if(strcmp(desc_curr->nume, desc->nume) > 0){ //daca numele serialului curent este mai mare din punct de vedere lexicografic
                    if(pre != NULL){ //Daca nu inserez la inceputul listei
                    //Refac legaturile pt. inserare inainte:
                    aux->urm = p; //campul urm al lui aux ia valoarea lui p
                    pre->urm = aux; //campul urm al lui pre ia valoarea lui aux
                    fprintf(f, "Serialul %s a fost adaugat la pozitia %d.\n", desc->nume, find_pos(aL, desc->nume));
                    return 1;
                }
                if(pre == NULL){ //Daca inserez la inceputul listei
                    aux->urm = *aL; //campul urm al lui aux ia valoarea lui *aL
                    *aL = aux; //inceputul listei devine aux
                    fprintf(f, "Serialul %s a fost adaugat la pozitia %d.\n", desc->nume, find_pos(aL, desc->nume));
                    return 1;
                }
            }
        }
    }
    //Daca am ajuns la sfarsitul listei
	aux->urm = NULL; //campul urm al lui aux este NULL
	pre->urm = aux; //deoarece p este NULL dupa parcurgerea intregii liste, pre detine adresa ultimului element, iar campul urm al lui pre devine aux
    fprintf(f, "Serialul %s a fost adaugat la pozitia %d.\n", desc->nume, find_pos(aL, desc->nume));
    //free(aux); 
    return 1;
}

//Functie ce insereaza un serial in lista top10; primeste adresa listei, informatia de tip void* de inserat, pozitia la care inserez si fisierul de output
int InsTop10(TLista* aL, void* ae, int poz, FILE *f)
{
    TLista l = *aL; //l ia adresa primului element din lista
    int count = 1; //counter de elemente 
    if(l != NULL) //daca lista nu e vida
        for(; l != NULL; l = l->urm){ //parcurg lista pentru a numara elementele
            if(count == 10){ //daca am gasit 10 elemente
                StergeNodFinal(aL); //pentru a adauga o intrare in lista, trebuie sa sterg ultimul element, cu ajutorul functiei StergeNodFinal
            } 
            count++; //la fiecare pas, incrementez count 
        }
    TLista aux = malloc(sizeof(TCelula)); //declar si aloc spatiu pentru o noua celula
    aux->info = ae; //plasez informatia in campul info
    InfoSerial *desc = (InfoSerial*)(((AQ)(aux->info))->info); //declar o variabila care va indica descrierea serialului de inserat
    if(find_pos(aL, desc->nume)) //Daca serialul se afla deja in lista (are o pozitie)
        return 0; //nu inserez
    if(poz == 1) //Daca trebuie sa inserez la pozitia 1
    {
        aux->urm = *aL; //campul urm al celulei aux ia valoarea primului element din  lista
        *aL = aux; //primul element devine aux
        fprintf(f, "Categoria top10: [");
        AfisareL(*aL, f); //afisez categoria top10 cu ajutorul functiei AfisareL
        return 1;
    }
    TLista p = *aL, pre = NULL; //p ia adresa primului element din lista, pre este elementul anterior lui p si este initializat cu NULL
    count = 1; //contorul pentru pozitie porneste de la 1
    for(; p != NULL; pre = p, p = p->urm)
    {
        if(count == poz) //daca am ajuns la pozitia dorita
        {
            //Refac legaturile pt. inserare inainte:
             aux->urm = p; //campul urm al lui aux ia valoarea lui p
             pre->urm = aux; //campul urm al lui pre ia valoarea lui aux
             fprintf(f, "Categoria top10: [");
             AfisareL(*aL, f); //afisez
             return 1;
        }
        if(p->urm == NULL) //Daca trebuie sa inserez pe ultima pozitie, si am ajuns la capatul listei
        {
            aux->urm = NULL; //campul urm al lui aux este NULL
            p->urm = aux; //campul urm al lui p ia valoarea lui aux
            fprintf(f, "Categoria top10: [");
            AfisareL(*aL, f); //afisez
            return 1;
        }
        ++count; //cresc contorul cu 1 
    }
    return 0;
}

//Functie ce afiseaza o lista (din cele 4 categorii); primeste o copie a listei si fisierul de output
void AfisareL(TLista aL, FILE *f) 
{
    AQ serial; //declar o variabila de tip coada in care rvoi retine un serial
    InfoSerial *desc; //desc indica descrierea unui serial
    if(aL != NULL) //daca lista nu e vida
    {
        serial = (AQ)((aL)->info); //"serial" retine serialul de la pasul curent 
        desc = (InfoSerial*)(serial->info); //desc retine descrierea serialului de la pasul curent
        fprintf(f, "(%s, %0.1f)", desc->nume, desc->rating); //afisez numele si ratingul primului serial, pentru a evita o virgula in plus la inceput
    }
        
    TLista l = aL; //l retine adresa primului element din aL
    if( l != NULL){ //daca lista nu e vida
        for (l = aL->urm; l != NULL; l = l->urm){ //parcurg lista de la cel de-al doilea element pana la sfarsit
            fprintf(f, ", ");  
            serial = (AQ)(l->info); //serial ia valoarea serialului de la pasul curent
            desc = (InfoSerial*)(serial->info); //desc ia descrierea serialului de la pasul curent
            fprintf(f, "(%s, %0.1f)", desc->nume, desc->rating); //afisez
        }
	
    }
	fprintf(f, "].\n");
}

//Functie care sterge ultimul nod al unei liste
void StergeNodFinal(TLista *L)
{
    TLista p = *L, pre = NULL; //declar doua variabile de tip lista cu care parcurg lista
    while(p->urm != NULL){
        pre = p;
        p = p->urm;
    } //parcurg lista pana la final
    pre->urm = NULL; //in urma parcurgerii listei, pre retine penultima pozitie, iar campul urm devin NULL, rupandu-se legatura cu p (ultima pozitie)
    //free(p->info); - explicatii in readme!!
    //free(p);
}

//Functie ce sterge serialul intitulat numeS din lista L
void StergeElem(TLista *L, char *numeS)
{
    if(*L == NULL) //Daca lista e vida, parasesc functia
        return;
    TLista p, pre; //variabile cu care parcurg lista, pre va fi elementul predecesor lui p
    InfoSerial *desc; //variabila ce indica descrierea unui serial
    for(p = *L, pre = NULL; p != NULL; pre = p, p = p->urm)
    {
         desc = (InfoSerial*)(((AQ)(p->info))->info); //desc ia valoarea descrierii serialului de la pasul curent
         if(strcmp(desc->nume, numeS) == 0) //daca am gasit serialul ce trebuie sters
         {
             if(p == *L) //daca este pe prima pozitie
             {
                 *L = p->urm; //inceputul listei se muta la urmatorul element
                // free(p->info);
                // free(p);
                 return;
             }
             else //daca e pe orice alta pozitie
             {
                 pre->urm = p->urm; //campul urm al predecesorului ia valoarea elementului urmator lui 
                 //free(p->info);  --explicatie readme!
                 //free(p);
                 return;
             }
         }
    }
}
//Functie care distruge lista aL
void DistrugeL(TLista* aL)
{
    TLista aux;
    while(*aL) { //cat timp lista e nevida
        aux = *aL; //aux ia valoarea inceputului listei
        *aL = aux->urm; //inceputul listei se muta la adresa urmatoare
        free(aux); //eliberez aux
    }
}
