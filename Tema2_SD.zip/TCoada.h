/* ARTENIE Beatrice-Diana - 314CB */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include "tlista.h"
#ifndef _FUNCTII_
#define _FUNCTII_
#endif

#ifndef COADA
#define COADA

typedef struct coada
{ 
	void *info;     // camp suplimentar pentru informatia legata de o coada (de tip InfoSerial sau InfoSezon) - nu de elementele acesteia !!
	size_t dime;   /* dim.element */
	TLista ic, sc;   /* adr.prima, ultima celula */
} TCoada, *AQ; // structura unei cozi

AQ InitQ(size_t d, void *info); /* creeaza coada vida cu elemente de dimensiune d */
int InsQ(void* c, void *ae);  /* insereaza un element intr-o coada */


#endif
