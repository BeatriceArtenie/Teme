/* ARTENIE Beatrice-Diana - 314CB */
#include "TCoada-V.h"
#include "tlista.h"
/* creeaza coada vida cu elemente de dimensiune d;
   este necesar si un al doilea parametru = numar maxim elemente in coada */
AQ InitQ(size_t d, void *info)
{ 
	AQ a = (AQ)malloc(sizeof(TCoada));  	/* adresa descriptor alocat */
  	if (!a) 
		return NULL;
	a->dime = d;
	a->info = info;
	a->sc = NULL;
	a->ic = NULL;

  	return a;
}

//Inserare in coada vida / nevida
int InsQ(void* c, void *ae)
{
	TLista aux;
	aux = (TLista)malloc(sizeof(TCelula));
	if(!aux)
		return 0;
	aux->info = ae;  //ae e alocata per element
	aux->urm = NULL;
	if(IC(c) == NULL)
	{
		IC(c) = aux; 
		SC(c) = aux;
	}
	else
	{
		SC(c)->urm = aux;
		SC(c) = aux;
	}
	if(!IC(c))
		printf("\nNu am reusit sa inserez sezonul/episodul/serialul in watch_later.\n");
	return 1;
	
}

void AfisareQ(void *s, FILE *f)
{
	AQ serial = (AQ)s;
	InfoSerial *descriere;
	descriere = (InfoSerial*)(serial->info);
	fprintf(f, "(%s, %0.1f)", descriere->nume, descriere->rating);
	//printf("(%s, %0.1f)", descriere->nume, descriere->rating);
}

void AfiQ(AQ s, FILE *f)
{
	TLista p = s->ic;
	AQ serial;
	InfoSerial *descriere = (InfoSerial*)malloc(sizeof(InfoSerial));
	for(;p != NULL; p = p->urm)
	{
		serial = (AQ)(p->info);
		descriere = (InfoSerial*)(serial->info);
		fprintf(f, "(%s, %0.1f)", descriere->nume, descriere->rating);
		printf("(%s, %0.1f)", descriere->nume, descriere->rating);
	}
}
