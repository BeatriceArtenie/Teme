/* ARTENIE Beatrice-Diana - 314CB */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "TCoada-V.h"
#include "tlista.h"

/* numar maxim elemente coada / stiva */
#define MAX 256

void add(TLista *L, InfoSerial *descriere, char **v, int count, FILE *f)
{
	
	AQ serial; //coada serial pe care o voi insera in lista
	serial = InitQ(sizeof(AQ), (void*)descriere); //initiez serialul cu informatia obtinuta in jobs
	int v_episoade[200], i; //In v_episoade retin sezoanele si duratele specifice ale fiecarui episod
	InfoSerial *desc = (InfoSerial*)(serial->info); //descrierea unui sezon
	for(i = 0; i < count; i++)
	{
		v_episoade[i] = atoi(v[i]); //Pentru a retine fiecare episod/ numar de episoade per sezon convertesc stringurile retinute in v la int
	}
	int j = 0;
	//Pentru inceput, inserez episoadele in sezonul corespunzator, apoi sezoanele in serial
	for(i = 0; i < desc->nr_sez; i++)
	{
		AQ sezon; // sezon de inserat in serial
		InfoSezon desc_sez; // descrierea sezonului
		desc_sez.nr_ep = v_episoade[j];  //Pe prima pozitie va fi mereu nr. de episoade al primului sezon
		j++; //avansez cu j
		int k = 0;
		for(; k < desc_sez.nr_ep; k++)
		{
			desc_sez.episoade[k] = v_episoade[j]; // retin toate episoadele acestui sezon in vectorul de episoade din InfoSezon
			j++; //incrementez j pt a avansa in v_episoade
		}
		sezon = InitQ(sizeof(int), (void *)&desc_sez); //Initiez sezonul cu informatia corespunzatoare
		for(k = 0; k < desc_sez.nr_ep; k++)
		{
			int rez = InsQ((void*)sezon, (void*)&(desc_sez.episoade[k])); //Pe rand, din vectorul de episoade, inserez fiecare episod in coada
			if(!rez) 
				exit(1);
		}
		int rez = InsQ((void*)serial, (void*)sezon); //Inserez sezonul in serial
		if(!rez)
			exit(1);
	}
	int rez = InsCat(L, (void*)serial, f); // Inserez serialul in lista corespunzatore
	if(!rez)
		printf("Nu am reusit sa introduc serialul in lista!\n");
}

void add_top(TLista *L, InfoSerial *descriere, char **v, int count, int pozitie, FILE *f)
{
	AQ serial; //coada serial pe care o voi insera in lista
	serial = InitQ(sizeof(AQ), (void*)descriere); //initiez serialul cu informatia obtinuta in jobs
	int v_episoade[200], i; //In v_episoade retin sezoanele si duratele specifice ale fiecarui episod
	InfoSerial *desc = (InfoSerial*)(serial->info); //descrierea unui sezon
	for(i = 0; i < count; i++)
	{
		v_episoade[i] = atoi(v[i]);  //Pentru a retine fiecare episod/ numar de episoade per sezon convertesc stringurile retinute in v la int
	}
	int j = 0;
	//Pentru inceput, inserez episoadele in sezonul corespunzator, apoi sezoanele in serial
	for(i = 0; i < desc->nr_sez; i++)
	{

		AQ sezon; // sezon de inserat in serial
		InfoSezon desc_sez; // descrierea sezonului
		desc_sez.nr_ep = v_episoade[j]; //Pe prima pozitie va fi mereu nr. de episoade al primului sezon
		j++; //avansez cu j
		int k = 0;
		for(; k < desc_sez.nr_ep; k++)
		{
			desc_sez.episoade[k] = v_episoade[j]; // retin toate episoadele acestui sezon in vectorul de episoade din InfoSezon
			j++; //incrementez j pt a avansa in v_episoade
		}
		sezon = InitQ(sizeof(int), (void *)&desc_sez);  //Initiez sezonul cu informatia corespunzatoare
		for(k = 0; k < desc_sez.nr_ep; k++)
		{
			int rez = InsQ((void*)sezon, (void*)&(desc_sez.episoade[k]));  //Pe rand, din vectorul de episoade, inserez fiecare episod in coada
			if(!rez)
				exit(1);
		}
		int rez = InsQ((void*)serial, (void*)sezon); //Inserez sezonul in serial
		if(!rez)
			exit(1);
	}
	int rez = InsTop10(L, (void*)serial, pozitie, f);  // Inserez serialul in lista corespunzatore
	if(!rez)
		printf("Nu am reusit sa introduc serialul in lista!\n");
}

void later(AQ *watch_later, char *nume, TLista *L, AQ tv_show, FILE *f)
{
	int rez;
	rez = InsQ((void*)(*watch_later), (void*)(tv_show)); // inserez serialul primit ca parametru
	AQ s = *watch_later; //retin in s coada watch_later
	TLista l = s->ic; // in l, inceputul listei de seriale
	fprintf(f, "Serialul %s se afla in coada de asteptare pe pozitia %d.\n", nume, find_pos(&l, nume)); 
	if(!rez)
		printf("\nNu am introdus serialul in watch_later!\n");
	StergeElem(L, nume); //sterg serialul din lista lui originala
}
void show(char *loc, TLista ID1, TLista ID2, TLista ID3, TLista ID4, AQ w_later, FILE *f)
{		
	int id;
	if(strcmp(loc, "1") == 0){ //daca id-ul cerut este 1
		
		id = atoi(loc);
		fprintf(f, "Categoria %d: [", id);
		AfisareL(ID1, f); //afisez lista 1
	}	
	if(strcmp(loc, "2") == 0){ //daca id-ul cerut este 2
		
		id = atoi(loc);
		fprintf(f, "Categoria %d: [", id); 
		AfisareL(ID2, f); //afisez lista 2
	}
	if(strcmp(loc, "3") == 0){   //daca id-ul cerut este 3
		
		id = atoi(loc);
		fprintf(f, "Categoria %d: [", id); 
		AfisareL(ID3, f); // afisez lista 3
	}
	if(strcmp(loc, "top10") == 0){ //daca se cere afisarea listei top10
		fprintf(f, "Categoria top10: [");
		id = atoi(loc);
		AfisareL(ID4, f); // afisez top10
	}
	if(strcmp(loc, "later") == 0){ //daca se cere afisarea cozii later
		fprintf(f, "Categoria later: [");
		if(IC(w_later) != NULL) //daca watch_later nu e vida
		{
			//AQ s = (AQ)(IC(w_later)->info); 
			TLista p = IC(w_later); //intr-o variabila p salvez adresa primului element din coada watch_later
			char *nume;
			float rating;
			
			for(; p->urm != NULL; p = p->urm){ //parcurg coada pana la penultimul element
				nume = ((InfoSerial*)(((AQ)(p->info))->info))->nume; //salvez numele si ratingul in variabile locale pentru a le printa mai usor in fisier 
				rating = ((InfoSerial*)(((AQ)(p->info))->info))->rating; 
				fprintf(f,"(%s, %0.1f), ", nume, rating);
			}
			nume = ((InfoSerial*)(((AQ)(p->info))->info))->nume; 
			rating = ((InfoSerial*)(((AQ)(p->info))->info))->rating; 
			fprintf(f,"(%s, %0.1f)", nume, rating);// afisez ultimul element separat, pentru a nu avea o virgula in plus la sfarsit
		}
		fprintf(f, "].\n");
	}
}
void jobs(char *fisier_in, char *fisier_out)
{
	TLista tendinte = NULL; //pentru inceput, declar si initializez listele cu NULL
	TLista documentare = NULL;
	TLista tutoriale = NULL;
	TLista top10 = NULL;
	AQ watch_later = InitQ(sizeof(AQ), NULL);
	
	FILE *f1, *f2; //declar pointeri pentru fisiere
	size_t len = 0; //setez lungimea fisierului la 0
	char * line = NULL; //Initializez pointerul de linie cu NULL

	f1 = fopen(fisier_in, "rt"); //deschid f1 pentru citire
    f2 = fopen(fisier_out, "wt"); //deschide f2 pentru scriere
    //Verific daca am deschis fisierele corect
	if (f1 == NULL)
		printf("Nu am putut deschide fisierul\n");
    //Parcurg liniile fisierului si le parsez cu strtok
	while (getline(&line, &len, f1) != -1) {
		char *job = strtok(line, " "); //primul cuvant reprezinta actiunea ce trebuie efectuata
		if(strcmp(job, "add") == 0) //daca se cere adaugarea unui serial intr-o categorie 
		{
			char *ID = strtok(NULL, " "); //al doilea cuvant reprezinta ID-ul serialului
			char *nume = strtok(NULL, " "); //al treilea cuvant reprezinta numele serialului
			char *rating = strtok(NULL, " "); //al patrulea cuvant reperezinta ratingul
			char *nr_sez = strtok(NULL, " "); //al cincilea cuvant reprezinta nr. de sezoane
			char *sez = strtok(NULL, " ");   //numarul de episoade al primului sezon
			char *v_sez[200]; //vector in care voi retine tot ceea ce tine de sezoanele serialului (nr. de episoade, durate)
			int i = 0, count = 0;
			while(sez != NULL) //cat timp sez pointeaza catre ceva
			{
				count++;
				v_sez[i++] = sez; //retin sez in vector
				if(sez[strlen(sez) - 1] == '\n'){  //daca am ajuns la capatul liniei, plasez pe ultimul caracter null terminator si ies din bucla
					sez[strlen(sez) - 1] = '\0';
					break;
				}
				sez = strtok(NULL, " "); //daca nu, continui parsarea liniei
			}
			InfoSerial *descriere = (InfoSerial*)malloc(sizeof(InfoSerial)); //declar si aloc spatiu pentru variabila descriere, ce va indica descrierea unui serial 
			int id = atoi(ID); // convertesc al doilea "cuvant" la int, deoarece reprezinta id-ul categoriei serialului
			descriere->ID = id; //completez campul id
			descriere->nume = strdup(nume); //completez campul nume
			float rt = atof(rating); //convertesc al patrulea "cuvant" la float, deoarece reprezinta ratingul serialului
			descriere->rating = rt; //completez campul rating
			int nr_s = atoi(nr_sez); //convertesc al cincilea "cuvant" la int, deoarece reprezinta nr. de sezoane al serialului
			descriere->nr_sez = nr_s; //completez campul nr_sez
			//In functie de id-ul serialului, il adaug in categoria tendinte, documentare sau tutoriale
			if(descriere->ID == 1) 
				add(&tendinte, descriere, v_sez, count, f2);
			else if(descriere->ID == 2)
				add(&documentare, descriere, v_sez, count, f2);
			else
				add(&tutoriale, descriere, v_sez, count, f2);
		}
		if(strcmp(job, "show") == 0) //daca se cere afisarea unei liste / stive / cozi 
		{
			char *ID = strtok(NULL, " "); //al doilea cuvant reprezinta ID-ul categoriei / numele cozii / numele stivei / lista top10
			ID[strlen(ID) - 1] = '\0'; //plasez pe ultimul caracter null terminator
			show(ID, tendinte, documentare, tutoriale, top10, watch_later, f2); //afisez cu ajutorul functiei show
		}
		if(strcmp(job, "add_top") == 0) //daca se cere adaugarea unui serial in top10
		{
			char *pozitie = strtok(NULL, " "); //al doilea cuvant reprezinta pozitia serialului in top19
			char *nume = strtok(NULL, " "); //al treilea cuvant reprezinta numele serialului
			char *rating = strtok(NULL, " "); //al patrulea cuvant reperezinta ratingul
			char *nr_sez = strtok(NULL, " "); //al cincilea cuvant reprezinta nr. de sezoane
			char *sez = strtok(NULL, " ");   //numarul de episoade al primului sezon
			char *v_sez[30]; //vector in care voi retine tot ceea ce tine de sezoanele serialului (nr. de episoade, durate episoade)
			int i = 0, count = 0;
			while(sez != NULL) //cat timp sez pointeaza catre ceva
			{
				count++;
				v_sez[i++] = sez; //retin sez in vector
				if(sez[strlen(sez) - 1] == '\n'){  //daca am ajuns la capatul liniei, plasez pe ultimul caracter null terminator si ies din bucla
					sez[strlen(sez) - 1] = '\0';
					break;
				}
				sez = strtok(NULL, " "); //daca nu, continui parsarea liniei
			}
			InfoSerial *descriere = (InfoSerial*)malloc(sizeof(InfoSerial)); //declar si aloc o variabila care indica descrierea unui serial
			int poz = atoi(pozitie); //convertesc pozitia in int
			int id = 4;
			descriere->ID = id; //in campul id plasez 4, dar acesta nu va fi folosit
			descriere->nume = strdup(nume); //completez campul "nume"
			float rt = atof(rating); //convertesc ratingul in float
			descriere->rating = rt; //completez campul rating
			int nr_s = atoi(nr_sez); //convertesc nr. de sezoane in int
			descriere->nr_sez = nr_s; //completez campul nr_sez
			add_top(&top10, descriere, v_sez, count, poz, f2); //adaug serialul in top10 cu ajutorul functiei add_top
		}
		if(strcmp(job, "later") == 0) //daca se cere adaugarea unui serial in coada watch_later
		{
			char *nume = strtok(NULL, " "); //al doilea cuvant reprezinta numele serialului de introdus
			nume[strlen(nume) - 1] = '\0'; //plasez pe ultimul caracter null terminatorul
			int found = 0; //variabila in care retin daca un serial a fost gasit sau nu
			TLista p;
			AQ serial; //variabila in care voi retine serialul de introdus (nu doar informatia)
			InfoSerial *desc; //declar pointer ce indica descrierea unui serial
			for(p = tendinte; p != NULL; p = p->urm)
			{
				desc = (InfoSerial*)(((AQ)(p->info))->info); //desc retine informatia pentru fiecare serial la pasul curent
				if(strcmp(desc->nume, nume) == 0) //compar numele fiecarui serial cu numele primit 
				{
					found = 1; //daca l-am gasit in categoria tendinte, found devine 1
					serial = (AQ)(p->info); //retin serialul in variabila "serial"
					break; //ies din bucla
				}
			}
			if(found == 1) //daca am gasit serialul
				later(&watch_later, nume, &tendinte, serial, f2); //il adaug cu ajutorul functiei later
			//Repet pentru categoriile documentare, tutoriale si top10:
			for(p = documentare; p != NULL; p = p->urm)
			{
				desc = (InfoSerial*)(((AQ)(p->info))->info);
				if(strcmp(desc->nume, nume) == 0)
				{
					found = 2;
					serial = (AQ)(p->info);
					break;
				}
			}
			if(found == 2)
				later(&watch_later, nume, &documentare, serial, f2);
			for(p = tutoriale; p != NULL; p = p->urm)
			{
				desc = (InfoSerial*)(((AQ)(p->info))->info);
				if(strcmp(desc->nume, nume) == 0)
				{
					found = 3;
					serial = (AQ)(p->info);
					break;
				}
			}
			if(found == 3)
				later(&watch_later, nume, &tutoriale, serial, f2);
			for(p = top10; p != NULL; p = p->urm)
			{
				desc = (InfoSerial*)(((AQ)(p->info))->info);
				if(strcmp(desc->nume, nume) == 0)
				{
					found = 4;
					serial = (AQ)(p->info);
					break;
				}
			}
			if(found == 4)
				later(&watch_later, nume, &top10, serial, f2);
		}
	}
	
	fclose(f1);
	fclose(f2);
}



int main(int argc, char **argv)
{
	jobs(argv[1], argv[2]);
  	return 0;
}
