/* ARTENIE Beatrice-Diana - 314CB */
#include "TCoada.h"

#ifndef _COADA_VECTOR_
#define _COADA_VECTOR_


typedef struct {
	int nr_ep;  //nr. de episoade dintr-un sezon
	int episoade[210];  //vector intreg doar pentru gestionarea episoadelor - implementarea se face cu liste!!
}InfoSezon; //structura pt. informatiile legate de un sezon

typedef struct {
	int ID;   //ID-ul  serialului
	char *nume;  // numele serialului
	float rating;  //ratingul serialului
	int nr_sez;    //numarul de sezoane al unul serial
}InfoSerial;  //structura pt. informatiile legate de un serial


/*- macrodefinitii - acces campuri -*/

#define IC(a) 	(((AQ)(a))->ic)
#define SC(a) 	(((AQ)(a))->sc)
#define DIME(a) (((AQ)(a))->dime)


#endif
