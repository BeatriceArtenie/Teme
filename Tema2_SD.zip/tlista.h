/* ARTENIE Beatrice-Diana - 314CB */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


#ifndef _LISTA_SIMPLU_INLANTUITA_
#define _LISTA_SIMPLU_INLANTUITA_

typedef struct celula
{
    void *info;
    struct celula * urm;
} TCelula, *TLista; /* tipurile Celula, Lista */

#define VidaL(L) ((L) == NULL)

typedef void (*TF)(void*, FILE *f);     /* functie afisare/eliberare un element */

/*-- operatii elementare --*/

int InsCat(TLista* aL, void* ae, FILE *f); /* insereaza un element cu informatia ae in aL si afiseaza un mesaj in f */
int InsTop10(TLista* aL, void* ae, int poz, FILE *f); /* insereaza un element cu informatia ae in aL la pozitia poz si afiseaza un mesaj in f */
void DistrugeL(TLista*);       /* elimina toate celulele din lista */
void AfisareL(TLista aL, FILE *f); /* afiseaza elementele listei intr-un fisier f */
void StergeNodFinal(TLista *L); /* sterge ultimul nod al unei liste */
void StergeElem(TLista *L, char *numeS); /* sterge serialul denumit numeS din lista */ 
int find_pos(TLista *L, char *name); /* gaseste pozitia serialului denumit numeS in lista */

#endif
