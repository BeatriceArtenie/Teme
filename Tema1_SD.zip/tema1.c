/* ARTENIE Beatrice-Diana - 314 CB */

#include "tema1.h"

//Functie care compara cheile celulelor (pentru functia de introducere)
int cmp_domains(void *el1, void *el2)
{
    //Salvez elementele de tip void * primite in elemente de tip TPereche
    TPereche p1 = *(TPereche*)el1;
    TPereche p2 = *(TPereche*)el2;
    return strcmp(p1.domeniu, p2.domeniu); //returnez valoarea functiei strcmp ce compara cheile
}

//Functie care insereaza un element intr-o lista
TLDI ins_lista(TLDI* aL, void* ae)
{
    //Prima data, aloc memorie pentru celula ce urmeaza sa fie inserata in lista
	TLDI aux = malloc(sizeof(TCelula2));
    //Verific daca am alocat cu succes
	if (!aux)
	    return 0;
    //Stochez informatia in campul info al celulei
    aux->info = ae;
    //In cazul in care lista e goala:
    if(*aL == NULL){
        //Leg celula de ea insasi (atat precedesorul, cat si succesorul ei este ea insasi)
        aux->urm = aux;
        aux->pre = aux;
        //Returnez celula creeata
        return aux;
    }
    //In cazul in care celula aux trebuie inserata inainte de prima celula din lista (cheia celulei aux e cea mai mica)
    if(cmp_domains((*aL)->info, ae) > 0)
    {
        //Refac legaturile:
        (*aL)->pre->urm = aux; //campul urm al ultimei celule din lista retine adresa lui aux
        aux->pre = (*aL)->pre; //campul pre al celulei aux retine adresa ultimei celule
        aux->urm = (*aL); //campul urm al celulei aux retine adresa primei celule
        (*aL)->pre = aux; //campul pre al primei celule retine adresa lui aux
        *aL = aux; //prima celula devine aux
        return *aL; //returnez lista
    }

    TLDI p = *aL; //pentru o parcurgere mai usoara, retin prima celula intr-o noua variabila
    while(cmp_domains(p->info, ae) < 0) //Cat timp nu am gasit un element cu cheia mai mare in lista
    {
        if(p->urm == *aL) //Daca am ajuns la finalul listei
        {
            //Refac legaturile, ca aux sa devina ultima celula
            aux->urm = *aL; //campul urm al celulei aux retine adresa primei celule
            aux->pre = p; //campul pre al lui aux retine adresa ultimei celule (p)
            p->urm = aux; //campul urm al ultimei celule retine adresa lui aux
            (*aL)->pre = aux; //ultima celula devine aux
            return *aL; //returnez lista
        }
        p = p->urm; //avansez, daca nu am ajuns la sfarsitul listei
    }
    //Daca nu am ajuns la sfarsit:
    p->pre->urm = aux; //campul urm al celulei de dinaintea lui p retine adresa lui aux
    aux->pre = p->pre; //campul pre al lui aux retine adresa predecesorului lui p
    p->pre = aux; //campul pre al celulei p retine adresa lui aux
    aux->urm = p; //campul urm al celulei aux retine adresa lui p
   
    return *aL; //returnez lista
//Mai multe detalii se regasesc in README.
}

//Functie de stergere a unui element din lista
int stergere_elem(TLDI *aL, void *ae)
{
    TLDI p, predecesor = NULL, aux;
    if(*aL == NULL)
        return -1;
    p = *aL;
    //Cautare cheie in lista *aL
    while (strcmp(((TPereche*)(p->info))->domeniu, ((TPereche*)ae)->domeniu) != 0)
    {
        if(p->urm == *aL) //Daca m-am intors de unde am plecat, nu am gasit cheia in lista
                return 0;
        predecesor = p; //predecesor ia valoarea lui p
        p = p->urm; //p avanseaza
    }
    //Daca cheia este singurul element din lista:
    if(p->urm == *aL && predecesor == NULL)
    {
        *aL = NULL; //atribui inceputului listei NULL
        free(p); //eliberez celula p
        return 1;
    }
    //Daca cheia este inceputul listei, dar nu singurul element:
    if(p == *aL)
    {
        predecesor = (*aL)->pre; //predecesorul devine ultima celula din lista
        *aL = (*aL)->urm; //A doua celula din lista devine inceputul listei
        predecesor->urm = *aL; //leg predecesorul la a doua celula din lista
        (*aL)->pre = predecesor; //leg a doua celula din lista la predecesor
        free(p); //eliberez p
        return 1;
    }
    //Daca cheia este sfarsitul listei
    else if(p->urm == *aL)
    {
        predecesor->urm = *aL; //leg celula antecedenta la inceputul listei
        (*aL)->pre = predecesor; //ultima celula din lista devine predecesorul ultimei celule
        free(p); //eliberez p
        return 1;
    }
    //Daca cheia se afla in interiorul listei
    else
    {
        aux = p->urm; //in aux plasez celula urmatoare lui p
        predecesor->urm = aux; //leg predecesorul la succesor
        aux->pre = predecesor; //leg succesorul la predecesor
        free(p); //eliberez p
    }
    
    return 1;
}

/* Functii basic pentru tabela hash */

//Functie de initializare a tabelei hash
TH* IniTH(size_t M, TFHash fh)
{
    TH *h = (TH*)calloc(sizeof(TH), 1); //aloc spatiu pentru o tabela si initializez cu 0
    //Verific daca am alocat cu succes
    if (!h) {
        printf("Nu am putut aloca tabela hash :(\n");
        return NULL;
    }

    h->v = (TLDI*)calloc(M, sizeof(TLDI)); //Aloc memorie pentru M liste in vectorul de liste
    //Verific daca am alocat vectorul cu succes
    if (!h->v) {
        printf("Nu am putut aloca vectorul de pointeri TLDI in hash :(\n");
        free(h); //Daca nu, eliberez tabela 
        return NULL;
    }

    h->M = M; //Stochez numarul de vectori in campul M al tabelei
    h->fh = fh; //Stochez functia hash in campul fh al tabelei

    return h; //Returnez tabela
}
void DistrTH(TH **ah)
{
    TLDI *p, el;

    //parcurgere cu pointeri
    for (p = (*ah)->v; p < (*ah)->v + (*ah)->M; p++) {
        //daca exista elemente corespunzatoare acestui hash
        //eliberam info din celula si apoi eliberam celula
        for (el = *p; el != NULL;) {
            el = el->urm;
            free((*p)->info);
        }
        free((*ah)->v);
    }
    free(*ah);
    *ah = NULL;
}



//Functie de inserare in tabela
int insTH(TH *a, void *ae, TFCmp cmp)
{
    int cod = a->fh(ae, a->M), rez; //in cod retin valoarea returnata de functia hash pentru elementul curent
    TLDI el;
    el = a->v[cod]; //retin inceputul listei in el
    //Daca lista e vida
    if(el == NULL)
    {
        a->v[cod] = ins_lista(a->v+cod, ae); //inserez elementul si ies din functie
        return 0;
    }
    //Daca tabela are un singur element
    if(el->urm == a->v[cod])
    {
        if (cmp(el->info, ae) == 1) //Daca e identic cu ceea ce vreau sa inserez ies din functie
            return 0;
    }
    //Daca primul element din lista coincide cu ceea ce vreau sa inserez, ies din functie
   if (cmp(el->info, ae) == 1) 
        return 0;
    //Parcurg lista de la al doilea la ultimul element    
    for(el = a->v[cod]->urm; el != a->v[cod]; el = el->urm) {
        if (cmp(el->info, ae) == 1) //Daca am gasit elementul pe care vreau sa-l inserez, ies din functie
            return 0;
    }
    a->v[cod] = ins_lista(a->v+cod, ae); //inserez
    return rez; 
}

//Functie de eliminare din tabela
int elimTH(TH *a, void *ae, TFCmp cmp)
{
    int cod = a->fh(ae, a->M), rez; //in cod retin numarul listei din care trebuie sa elimin elementul
    rez = stergere_elem(a->v+cod, ae); //sterg elementul din lista

    return rez;
}

//Functie de calculare a codului hash
int codHash(void *element, size_t M)
{
	TPereche *Pereche = (TPereche*)element; //Creez un pointer pentru valoarea primita
	char *domeniu = Pereche->domeniu;
	int s = 0; //initializez suma cu 0
	for(int i = 0; domeniu[i] != '\0'; i++)
		s = s + domeniu[i]; //adun valoarea fiecarei litere la suma
	return (s % M); //returnez restul impartirii lui s la M
}

//Functie de comparare a doua valori (similara cu cea de comparare a cheilor)
int cmpPereche(void *e1, void *e2)
{
	TPereche *Pereche1 = (TPereche*)e1;
	TPereche *Pereche2 = (TPereche*)e2;

	if (strcmp(Pereche1->ip, Pereche2->ip) != 0)
		return 0;

	return 1;
}

//Functie de printare a tabelei
void print(FILE *f, TH* ah)
{
    TLDI p, el; //Pentru usurinta parcurgerii, declar doua variabile de tip lista
    int i;
    //Parcurg vectorul de liste
    for (i = 0; i < ah->M; i++) {
        if(ah->v[i] != NULL){ //Daca am gasit o lista nenula
        p = ah->v[i]; //Retin primul element in p
        el = p; //si in el
        if (p) { //Daca primul element e nenul
            fprintf(f, "%d: ", i);
            for(el = p; el->urm != p; el = el->urm) //parcurg lista pana la ultimul element
                fprintf(f, "%s ", ((TPereche*)(el->info))->ip); //printez valoarea informatiei
            fprintf(f, "%s ", ((TPereche*)(el->info))->ip);  //Deoarece for-ul nu printeaza si ultima valoare, o printez separat  
            fprintf(f, "\n");
        }
        }
    }
}

//Functia de introducere a unei perechi (cheie, valoare) in tabelaa
void put(TH *h, char *dom, char *ip)
{
    TPereche *Pereche = NULL; //Initializez un pointer de tip TPereche cu NULL
    Pereche = (TPereche*)malloc(sizeof(TPereche)); //Aloc memorie pentru un element de tip TPereche
    //Verific daca am alocat cu succes
        if(!Pereche)
            printf("Nu am putut aloca memorie pentru pereche\n");
    //Completez campurile elementului
    strcpy(Pereche->domeniu, dom);
	strcpy(Pereche->ip, ip);
    int rez = insTH(h, Pereche, cmpPereche); //inserez
   
}

//Functie de stergere a unei perechi (cheie, valoare) din tabela
void remove_pair(TH *h, char *dom, char *ip)
{
    TPereche *Pereche = NULL;//Initializez un pointer de tip TPereche cu NULL
    Pereche = (TPereche*)malloc(sizeof(TPereche)); //Aloc memorie pentru un element de tip TPereche
     //Verific daca am alocat cu succes
        if(!Pereche)
            printf("Nu am putut aloca memorie pentru pereche\n");
    strcpy(Pereche->domeniu, dom); //Completez campul domeniu
    int rez = elimTH(h, Pereche, cmpPereche); //Elimin
    free(Pereche); // eliberez pointerul alocat
}

//Functia de cautare a unui element in tabela
int find(FILE *f, TH *a, void *ae, TFCmp cmp)
{
    int cod = a->fh(ae, a->M), rez; //Calculez codul elementului si il retin in variabila cod
    TLDI el = a->v[cod]; //Retin inceputul listei intr-o variabila de tip TLDI
    //Daca lista e vida
    if(el == NULL)
    {
        fprintf(f, "False\n"); //Nu am gasit elementul
        return 0; 
    }
    //Parcurg lista pana la penultimul element inclusiv
    for(el = a->v[cod]; el->urm != a->v[cod]; el = el->urm) {
        if (strcmp(((TPereche*)(el->info))->domeniu, ((TPereche*)ae)->domeniu) == 0) //Daca am gasit cheia cautata
        {
            fprintf(f, "True\n"); //printez "True"
            return 0;
        }  
    }
    //Verific si ultimul element din lista
    if (strcmp(((TPereche*)(el->info))->domeniu, ((TPereche*)ae)->domeniu) == 0)
    {
        fprintf(f, "True\n");
        return 0;
    }
    //Daca nici una din situatiile de mai sus nu au fost relevante, nu am gasit elementul  
    fprintf(f, "False\n");
    return 0;
}

//Functie de printare a valorii unei chei
int get(FILE *f, TH *a, void *ae, TFCmp cmp)
{
    int cod = a->fh(ae, a->M); //Calculez codul elementului si il retin in variabila cod
    //printf("Cod calculat: %d\n", cod); 
    TLDI el = a->v[cod]; //Retin inceputul listei intr-o variabila de tip TLDI
    //Daca lista e vida
    if(el == NULL)
    {
        fprintf(f, "NULL\n"); //Nu am gasit elementul
        return 0;
    }
    //Parcurg lista pana la penultimul element inclusiv
    for(el = a->v[cod]; el->urm != a->v[cod]; el = el->urm) {
        if (strcmp(((TPereche*)(el->info))->domeniu, ((TPereche*)ae)->domeniu) == 0) //Daca am gasit cheia cautata
        {
            fprintf(f, "%s\n", ((TPereche*)(el->info))->ip); //printez valoarea sa 
            return 0;
        }  
    }
    //Verific si ultimul element
    if (strcmp(((TPereche*)(el->info))->domeniu, ((TPereche*)ae)->domeniu) == 0)
    {
        fprintf(f, "%s\n", ((TPereche*)(el->info))->ip);
        return 0;
    }  
    //Daca nici una din situatiile de mai sus nu e relevanta, nu am gasit cheia pentru a printa valoarea
    fprintf(f, "NULL\n");
    return 0;
}

//Functia de printare a unei liste
int print_bucket(FILE *f, TH *a, int cod)
{
    //In cazul in care codul primit nu exista in tabela
   if(cod >= a->M)
   {
      return 0;  //ies din functie
   }
    TLDI p = a->v[cod]; //Retin primul element in p
    //Verific daca lista e vida:
    if(a->v[cod] == NULL)
    {
        fprintf(f, "VIDA\n");
        return 0;
    }
    //Daca nu e vida, printez fiecare element din lista
    do{
        fprintf(f, "%s ", ((TPereche*)(p->info))->ip);
        p = p->urm;
    }while(p->urm != a->v[cod]);
    //Deoarece am exclus din parcurgere ultimul element, il printez separat
    fprintf(f, "%s ", ((TPereche*)(p->info))->ip);
    fprintf(f, "\n");
    return 0;
}

void jobs(char *numeFisier_in, char *numeFisier_out, TH *h)
{
	FILE *f1, *f2; //declar pointeri pentru fisiere
	size_t len = 0; //setez lungimea fisierului la 0
	char * line = NULL; //Initializez pointerul de linie cu NULL

	f1 = fopen(numeFisier_in, "rt"); //deschid f1 pentru citire
    f2 = fopen(numeFisier_out, "wt"); //deschide f2 pentru scriere
    //Verific daca am deschis fisierele corect
	if (f1 == NULL)
		printf("Nu am putut deschide fisierul\n");
    //Parcurg liniile fisierului si le parsez cu strtok
	while (getline(&line, &len, f1) != -1) {
		char *job = strtok(line, " "); //primul cuvant reprezinta actiunea ce trebuie efectuata
		char *domeniu = strtok(NULL, " "); //al doilea cuvant reprezinta cheia
		char *ip = strtok(NULL, " "); //al treilea cuvant reprezinta valoarea

        //Verific daca la oricare din cuvintele citite se sfarseste linia; daca da, adaug un null terminator
		if (job[strlen(job) - 1] == '\n')
			job[strlen(job) - 1] = '\0';
		else if (domeniu[strlen(domeniu) - 1] == '\n')
			domeniu[strlen(domeniu) - 1] = '\0';
		else if (ip[strlen(ip) - 1] == '\n')
			ip[strlen(ip) - 1] = '\0';

		if(strcmp("put", job) == 0) //daca primul cuvant este "put", apelez put
			put(h, domeniu, ip);
		
		if(strcmp(job, "print") == 0) //daca primul cuvant este "print", apelez print
        {
            print(f2, h);
        }
        if(strcmp(job, "remove") == 0) //daca primul cuvant este "remove", apelez remove
            remove_pair(h, domeniu, ip);
        if(strcmp(job, "find") == 0) //daca primul cuvant este "find"
        {
             
            TPereche *Pereche = NULL;
            Pereche = (TPereche*)malloc(sizeof(TPereche)); //aloc memorie pentru element,
            if(!Pereche)
                printf("Nu am putut aloca memorie pentru pereche\n");
            strcpy(Pereche->domeniu, domeniu); //retin cheia in campul corespunzator
            int rez = find(f2, h, Pereche, cmpPereche); //apelez find
        }
        if(strcmp(job, "get") == 0) //daca primul cuvant este "get"
        {
            TPereche *Pereche = NULL; //Creez un pointer de tip TPereche
            Pereche = (TPereche*)malloc(sizeof(TPereche)); //aloc memorie pentru element
            if(!Pereche)
                printf("Nu am putut aloca memorie pentru pereche\n");
            strcpy(Pereche->domeniu, domeniu);//retin cheia in campul corespunzator
            int rez = get(f2, h, Pereche, cmpPereche); //apelez get
            free(Pereche);
        }    
        if (strcmp(job, "print_bucket") == 0) //daca primul cuvant este "remove"
        {
            int cod = atoi(domeniu); //al doilea cuvant reprezinta, in cazul acesta, numarul listei de printat, deci transform stringul in intreg
            int rez = print_bucket(f2, h, cod); //apelez print_bucket
        }
        
    }
        //Inchid fisierele
        fclose(f1);
        fclose(f2);
}


int main(int argc, char **argv)
{
	TH * h = NULL; //Declar un pointer pentru tabela si il initiez cu NULL
    size_t M = atoi(argv[1]); //convertesc al doilea parametru la int
	h = (TH*)IniTH(M, codHash); //initiez tabela hash
    //Verific daca am initiat tabela cu succes
	if (h == NULL) {
		printf("Tabela hash nu a putut fi generata\n");
        return 0;
	}
	jobs(argv[2], argv[3], h); //apelez functia jobs
    return 0;
}
