/* ARTENIE Beatrice-Diana - 314 CB */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#ifndef _TAB_HASH_
#define _TAB_HASH_

typedef int (*TFElem)(void*);     /* functie prelucrare element */
typedef int (*TFCmp)(void*, void*); /* functie de comparare doua elemente */
typedef void (*TF)(FILE*, void*);     /* functie afisare/eliberare un element */
typedef int (*TFHash)(void*, size_t);

typedef struct celula2
{
	void *info;              /* adresa element extern */
	struct celula2 *pre, *urm;  /* legaturi spre celulele vecine */
} TCelula2, *TLDI;

typedef struct 
{
    char domeniu[30];
    char ip[30];
}TPereche;

typedef struct
{
    size_t M;
    TFHash fh;
    TLDI *v;
} TH;


#endif