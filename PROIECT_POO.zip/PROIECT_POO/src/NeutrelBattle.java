import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;

public class NeutrelBattle extends Battle {
     public Arena arena;
     public ArrayList<Pokemon> neutrals;
     Pokemon neutrel;

    public NeutrelBattle() {
    }

    public NeutrelBattle(Arena arena, String neutrelType) throws FileNotFoundException {
        this.arena = arena;
        Gson gson = new Gson();
        JsonReader fileReader = new JsonReader(new FileReader("Neutreli.json"));
        Type REVIEW_TYPE = new TypeToken<ArrayList<Pokemon>>() {}.getType();
        this.neutrals = gson.fromJson(fileReader, REVIEW_TYPE);
        if(neutrelType.equals("neutrel1")){
            this.neutrel = neutrals.get(0);
        }

        if(neutrelType.equals("neutrel2")){
            this.neutrel = neutrals.get(1);
        }

    }

    @Override
    public void lupta(Pokemon pokemon1, Pokemon pokemon2, Logger log) throws IOException {
        GenericBattle battle = new GenericBattle(arena, neutrals);
        battle.genericBattle(pokemon1, neutrel, log);
        //Logger log = new Logger(whereToLog);
        /*log.beginningOfBattle(pokemon1, neutrel);
        Pokemon originalCharacteristics = new Pokemon(pokemon1.nume, pokemon1.HP, pokemon1.normalAttack,
                pokemon1.specialAttack, pokemon1.normalDefense, pokemon1.specialDefense, pokemon1.ability1,
                pokemon1.ability2, pokemon1.objects);
        Pokemon originalNeutrel = new Pokemon(neutrel.nume, neutrel.HP, neutrel.normalAttack, neutrel.specialAttack,
                neutrel.normalDefense, neutrel.specialDefense, neutrel.ability1, neutrel.ability2,
                neutrel.objects);
        Random random = new Random();
        int randIndex = random.nextInt(pokemon1.objects.size());
        ExtraObject randomObject = pokemon1.objects.get(randIndex);
        pokemon1.addObjectPerks(randomObject);
        ArrayList<String> events = new ArrayList<>();
        events.add("Attack");
        events.add("Ability1");
        events.add("Ability2");
        int cooldownTime1 = pokemon1.ability1.cooldown;
        int cooldownTime2 = pokemon1.ability2.cooldown;
        int ability1WasUsed = 0;
        int ability2WasUsed = 0;
        while(pokemon1.HP > 0 && neutrel.HP > 0){
            randIndex = random.nextInt(events.size());
            String event = events.get(randIndex);
            if(ability1WasUsed == 1)
                pokemon1.ability1.cooldown--;
            if(ability2WasUsed == 1)
                pokemon1.ability2.cooldown--;
            if(event.equals("Attack")){
                if(pokemon1.normalAttack != -1){
                    log.attack("atac normal", pokemon1, cooldownTime1, cooldownTime2);
                    neutrel.HP = neutrel.HP - pokemon1.normalAttack + neutrel.normalDefense;
                    if(!neutrel.isStun && !pokemon1.canDodge){
                        pokemon1.HP = pokemon1.HP - neutrel.normalAttack + pokemon1.normalDefense;
                        log.attack("atac normal", neutrel, 0, 0);
                    }
                    else{
                        log.attack("atac normal", neutrel, 0, 0);
                        neutrel.isStun = false;
                        pokemon1.canDodge = false;
                    }
                }
                else{
                    log.attack("atac special", pokemon1, cooldownTime1, cooldownTime2);
                    neutrel.HP = neutrel.HP - pokemon1.specialAttack + neutrel.specialDefense;
                    if(!neutrel.isStun && !pokemon1.canDodge){
                        pokemon1.HP = pokemon1.HP - neutrel.normalAttack + pokemon1.normalDefense;
                        log.attack("atac normal", neutrel, 0, 0);
                    }
                    else{
                        log.attack("atac normal", neutrel, 0, 0);
                        neutrel.isStun = false;
                        pokemon1.canDodge = false;
                    }
                }
            }
            else if(event.equals("Ability1")){
                if(!neutrel.isStun && !pokemon1.canDodge){
                    pokemon1.HP = pokemon1.HP - neutrel.normalAttack + pokemon1.normalDefense;
                    log.attack("atac normal", neutrel, 0,0);
                }
                else{
                    log.attack("atac normal", neutrel, 0, 0);
                    pokemon1.canDodge = false;
                    neutrel.isStun = false;
                }
                if(pokemon1.ability1.cooldown == cooldownTime1){
                    events.remove("Ability1");
                    ability1WasUsed = 1;
                    log.attack("Ability1", pokemon1, cooldownTime1, cooldownTime2);
                    if(pokemon1.ability1.stun == 1)
                        neutrel.isStun = true;
                    if(pokemon1.ability1.dodge == 1)
                        pokemon1.canDodge = true;
                    neutrel.HP = neutrel.HP - pokemon1.ability1.damage;
                }
            }
            else{
                if(!neutrel.isStun && !pokemon1.canDodge){
                    pokemon1.HP = pokemon1.HP - neutrel.normalAttack + pokemon1.normalDefense;
                    log.attack("atac normal", neutrel, 0, 0);
                }
                else{
                    log.attack("atac normal", neutrel, 0, 0);
                    neutrel.isStun = false;
                    pokemon1.canDodge = false;
                }
                if(pokemon1.ability2.cooldown == cooldownTime2){
                    ability2WasUsed = 1;
                    events.remove("Ability2");
                    log.attack("Ability2", pokemon1, cooldownTime1, cooldownTime2);
                    if(pokemon1.ability2.stun == 1)
                        neutrel.isStun = true;
                    if(pokemon1.ability2.dodge == 1)
                        pokemon1.canDodge = true;
                    neutrel.HP = neutrel.HP - pokemon1.ability2.damage;
                }
            }
            if(pokemon1.ability1.cooldown == 0){
                pokemon1.ability1.cooldown = cooldownTime1;
                events.add("Ability1");
                ability1WasUsed = 0;
            }
            if(pokemon1.ability2.cooldown == 0){
                pokemon1.ability2.cooldown = cooldownTime2;
                events.add("Ability2");
                ability2WasUsed = 0;
            }
        }
        if(neutrel.HP > 0){
            pokemon1.addPointsToWinner(pokemon1, originalNeutrel, originalCharacteristics);
            log.showWinner(neutrel);
            //return neutrel;
        }
        else{
            pokemon1.addPointsToWinner(neutrel, originalCharacteristics, originalNeutrel);
            log.showWinner(pokemon1);
            //return pokemon1;
        }*/
    }
}
