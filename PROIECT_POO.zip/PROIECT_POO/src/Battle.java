import java.io.IOException;

// PENTRU FACTORY
public abstract class Battle {
    public abstract void lupta(Pokemon pokemon1, Pokemon pokemon2, Logger log) throws IOException;
}
