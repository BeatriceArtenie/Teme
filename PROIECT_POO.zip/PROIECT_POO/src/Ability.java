public class Ability {
    public int damage;
    public int stun;
    public int dodge;
    public int cooldown;

    public Ability() {
    }

    public Ability(int damage, int stun, int dodge, int cooldown) {
        this.damage = damage;
        this.stun = stun;
        this.dodge = dodge;
        this.cooldown = cooldown;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getStun() {
        return stun;
    }

    public void setStun(int stun) {
        this.stun = stun;
    }

    public int getDodge() {
        return dodge;
    }

    public void setDodge(int dodge) {
        this.dodge = dodge;
    }

    public int getCooldown() {
        return cooldown;
    }

    public void setCooldown(int cooldown) {
        this.cooldown = cooldown;
    }

    public String toString(){
        return "\nDamage: " + damage + "\nStun: " + stun + "\nDodge: " + dodge +
                "\nCooldown: " + cooldown;
    }
}
