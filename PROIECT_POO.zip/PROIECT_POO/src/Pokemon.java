import java.util.ArrayList;

public class Pokemon {
    public String nume;
    public int HP;
    public int normalAttack;
    public int specialAttack;
    public int normalDefense;
    public int specialDefense;
    public Ability ability1;
    public Ability ability2;
    public ArrayList<ExtraObject> objects;
    public boolean isStun;
    public boolean canDodge;

    public Pokemon() {
        this.isStun = false;
        this.canDodge = false;
    }

    public Pokemon(String nume, int HP, int attack,
                   int specialAttack, int defense, int specialDefense, Ability ability1,
                   Ability ability2, ArrayList<ExtraObject> objects) {
        this.nume = nume;
        this.HP = HP;
        this.normalAttack = attack;
        this.specialAttack = specialAttack;
        this.normalDefense = defense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
        this.objects = objects;
        this.isStun = false;
        this.canDodge = false;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public int getNormalAttack() {
        return normalAttack;
    }

    public void setNormalAttack(int normalAttack) {
        this.normalAttack = normalAttack;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public int getNormalDefense() {
        return normalDefense;
    }

    public void setNormalDefense(int normalDefense) {
        this.normalDefense = normalDefense;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public Ability getAbility1() {
        return ability1;
    }

    public void setAbility1(Ability ability1) {
        this.ability1 = ability1;
    }

    public Ability getAbility2() {
        return ability2;
    }

    public void setAbility2(Ability ability2) {
        this.ability2 = ability2;
    }

    public ArrayList<ExtraObject> getObjects() {
        return objects;
    }

    public void setObjects(ArrayList<ExtraObject> objects) {
        this.objects = objects;
    }

    public boolean isStun() {
        return isStun;
    }

    public void setStun(boolean stun) {
        isStun = stun;
    }

    public boolean isCanDodge() {
        return canDodge;
    }

    public void setCanDodge(boolean canDodge) {
        this.canDodge = canDodge;
    }

    public void addObjectPerks(ExtraObject object){
        this.HP += object.HP;
        if(this.normalAttack != -1)
            this.normalAttack += object.attack;
        if(this.specialAttack != -1)
            this.specialAttack += object.specialAttack;
        this.normalDefense += object.defense;
        this.specialDefense += object.specialDefense;
        for(int i = 0; i < this.objects.size(); i++){
            if(this.objects.get(i).nume.equals(object.nume))
                this.objects.remove(i);
        }
    }

    public void addPointsToWinner(Pokemon loser, Pokemon origChrW, Pokemon origChrL){
        this.HP = origChrW.HP + 1;
        this.normalAttack = origChrW.normalAttack;
        if(this.normalAttack != -1)
            this.normalAttack += 1;
        this.specialAttack = origChrW.specialAttack;
        if(this.specialAttack != -1)
            this.specialAttack += 1;
        this.normalDefense = origChrW.normalDefense + 1;
        this.specialDefense = origChrW.specialDefense + 1;
        this.ability1 = origChrW.ability1;
        this.ability2 = origChrW.ability2;
        this.objects = origChrW.objects;
        this.isStun = origChrW.isStun;
        this.canDodge = origChrW.canDodge;

        loser.HP = origChrL.HP;
        loser.normalAttack = origChrL.normalAttack;
        loser.specialAttack = origChrL.specialAttack;
        loser.normalDefense = origChrL.normalDefense;
        loser.specialDefense = origChrL.specialDefense;
        loser.ability1 = origChrL.ability1;
        loser.ability2 = origChrL.ability2;
        loser.objects = origChrL.objects;
        loser.isStun = origChrL.isStun;
        loser.canDodge = origChrL.canDodge;
    }

    public String toString(){
        String showPokemon = "";
        showPokemon += "\nNume: " + nume + "\nHP: " + HP + "\nNormal Attack: " + normalAttack +
                "\nSpecial Attack: " + specialAttack + "\nNormal Defense: " + normalDefense +
                "\nSpecial Defense: " + specialDefense + "\n--------Ability 1--------" +
                ability1 + "\n--------Ability 2--------" + ability2 +
                "\n__________Objects__________";
        if(this.objects != null)
            for(int i = 0; i < objects.size(); i++){
                showPokemon += "\n  ### Object " + i + " ###" + objects.get(i);
            }
        showPokemon += "\n\t####\n";
        return showPokemon;
    }
}
