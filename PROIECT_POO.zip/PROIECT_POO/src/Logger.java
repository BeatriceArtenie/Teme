import java.io.*;

public class Logger {
    public String whereToLog;
    public File outputFile;
    public FileWriter fw;
    public BufferedWriter bw;

    public Logger(String whereToLog, File outputFile, FileWriter fw, BufferedWriter bw) throws IOException {
        this.whereToLog = whereToLog;
        this.outputFile = outputFile;
        this.fw = fw;
        this.bw = bw;
    }

    public void beginningOfBattle(Pokemon pokemon1, Pokemon pokemon2) throws IOException {
        String logLine = "------------Incepe o noua lupta!------------" +
                "\nIn arena intra primul antrenor cu: \n" + pokemon1.nume + "\n";
        if(pokemon2.nume.equals("Neutrel1") || pokemon2.nume.equals("Neutrel2"))
            logLine += "impreuna cu: \n" + pokemon2.nume + "\n";
        else
            logLine += "si cel de-al doilea antrenor cu: \n" + pokemon2.nume;
        logLine += "\n--------------------------------------------\n";

        if(whereToLog.equals("stdin")){
            System.out.println(logLine);
        }
        else{
            bw.write(logLine);
            bw.newLine();
            //bw.close();
        }
    }
    public void showBasicStatistics(Pokemon pokemon, int cooldown1, int cooldown2) throws IOException {
        String logLine = "Statisticile curente ale lui " + pokemon.nume + ":\n" +
                "HP: " + pokemon.HP;
        if(pokemon.ability1.cooldown != cooldown1 && pokemon.ability1.cooldown > 0)
            logLine += "\nCooldown abilitate 1: " + pokemon.ability1.cooldown + "\n";
        if(pokemon.ability2.cooldown != cooldown2 && pokemon.ability2.cooldown > 0)
            logLine += "\nCooldown abilitate 2: " + pokemon.ability2.cooldown + "\n\n";
        if(whereToLog.equals("stdin"))
            System.out.println(logLine);
        else{
            bw.write(logLine);
            bw.newLine();
            //bw.close();
        }
    }
    public void attack(String type, Pokemon pokemon, int cooldown1, int cooldown2) throws IOException {
        String logLine = "";
        if(pokemon.isStun)
            logLine += pokemon.nume + " este stunned. Nu poate face nimic." + "\n";
        else{
            if(type.equals("atac normal")){
                logLine += pokemon.nume + " foloseste atacul normal." + "\n";
            }
            if(type.equals("atac special"))
                logLine += pokemon.nume + " foloseste atacul special." + "\n";
            if(type.equals("Ability1") ){
                logLine += pokemon.nume + " isi foloseste abilitatea 1." + "\n";
                if(pokemon.ability1.stun == 1)
                    logLine += "Acesta isi ingheata adversarul urmatoarea runda." + "\n";
                if(pokemon.ability1.dodge == 1)
                    logLine += "Acesta poate evita atacul adversarului." + "\n";
            }
            if(type.equals("Ability2")){
                logLine += pokemon.nume + " isi foloseste abilitatea 2." + "\n";
                if(pokemon.ability2.stun == 1)
                    logLine += "Acesta isi ingheata adversarul urmatoarea runda." + "\n";
                if(pokemon.ability2.dodge == 1)
                    logLine += "Acesta poate evita atacul adversarului." + "\n";
            }
        }
        if(whereToLog.equals("stdin"))
            System.out.println(logLine);
        else{
            bw.write(logLine);
            bw.newLine();
            //bw.close();
        }
        showBasicStatistics(pokemon, cooldown1, cooldown2);
    }
    public void showWinner(Pokemon pokemon) throws IOException {
        String logLine = "Castigatorul acestei batalii este " + pokemon.nume + "!\n";
        logLine += "HP: " + pokemon.HP + "\n";
        if(pokemon.normalAttack != -1)
            logLine += "Atac normal: " + pokemon.normalAttack + "\n";
        if(pokemon.specialAttack != -1)
            logLine += "Atac special: " + pokemon.specialAttack + "\n";
        logLine += "Defense: " + pokemon.normalDefense + "\n" +
                "Special defense: " + pokemon.specialDefense + "\n";
        if(whereToLog.equals("stdin"))
            System.out.println(logLine);
        else{
            bw.write(logLine);
            bw.newLine();
            bw.close();
        }
    }
}
