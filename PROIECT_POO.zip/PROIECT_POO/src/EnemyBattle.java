import java.io.IOException;

public class EnemyBattle extends Battle{
    public Arena arena;

    public EnemyBattle(){

    }

    public EnemyBattle(Arena arena){
        this.arena = arena;
    }

    @Override
    public void lupta(Pokemon pokemon1, Pokemon pokemon2, Logger log) throws IOException {
        GenericBattle battle = new GenericBattle(arena, null);
        battle.genericBattle(pokemon1, pokemon2, log);
    }
}
