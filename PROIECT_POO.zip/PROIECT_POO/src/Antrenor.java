public class Antrenor {
    public String nume;
    public String varsta;
    public Pokemon[] pokemoni;

    public Antrenor() {
    }

    public Antrenor(String nume, String varsta, Pokemon[] pokemoni) {
        this.nume = nume;
        this.varsta = varsta;
        this.pokemoni = pokemoni;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getVarsta() {
        return varsta;
    }

    public void setVarsta(String varsta) {
        this.varsta = varsta;
    }

    public Pokemon[] getPokemoni() {
        return pokemoni;
    }

    public void setPokemoni(Pokemon[] pokemoni) {
        this.pokemoni = pokemoni;
    }

    public Pokemon bestPokemon(){
        int max = 0;
        Pokemon best = new Pokemon();
        for(Pokemon p : pokemoni){
            int sum = 0;
            sum += p.HP + p.normalDefense + p.specialDefense;
            if(p.normalAttack != -1)
                sum += p.normalAttack;
            if(p.specialAttack != -1)
                sum += p.specialAttack;
            if(max < sum){
                max = sum;
                best = p;
            }
            if(max == sum && p.nume.compareTo(best.nume) < 0)
                best = p;
        }
        return best;
    }

    public String toString(){
        String showAntrenor = "";
        showAntrenor += "Nume: " + nume + "\nVarsta: " + varsta +
        "\n<<<<<<< POKEMONI >>>>>>>>\n";
        for(int i = 0; i < pokemoni.length; i++)
            showAntrenor += "\t~ Pokemonul " + i + " ~" + pokemoni[i];
        return showAntrenor;
    }
}
