import java.io.FileNotFoundException;

public class BattleFactory {
    public Arena arena;

    public BattleFactory(Arena arena) {
        this.arena = arena;
    }

    public Battle beginBattle(String battleType) throws FileNotFoundException {
        return switch (battleType) {
            case "vsNeutrel1" -> new NeutrelBattle(arena, "neutrel1");
            case "vsNeutrel2" -> new NeutrelBattle(arena, "neutrel2");
            case "vsTrainer" -> new EnemyBattle(arena);
            default -> null;
        };
    }

}
