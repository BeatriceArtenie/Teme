import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;

public class Arena {
    //Lista de antrenori ce va fi citita din fisier:
    public ArrayList<Antrenor> antrenori;

    public Arena(ArrayList<Antrenor> antrenori) {
        this.antrenori = antrenori;
    }

    public Arena() {
    }

    public ArrayList<Antrenor> getAntrenori() {
        return antrenori;
    }

    public void setAntrenori(ArrayList<Antrenor> antrenori) {
        this.antrenori = antrenori;
    }

    // Metoda ce citeste din fisierul de intrare lista de
    public ArrayList<Antrenor> readFile(String fileName, Type REVIEW_TYPE) throws FileNotFoundException {
        this.antrenori = new ArrayList<>();
        Gson gson = new Gson();
        File testFile = new File(fileName);
        JsonReader fileReader = new JsonReader(new FileReader(fileName));
        return gson.fromJson(fileReader, REVIEW_TYPE);
    }

    public static void main(String[] args) throws IOException {
        /*File outputFile = new File("output.out");
        FileWriter fw = new FileWriter(outputFile.getName());
        BufferedWriter bw = new BufferedWriter(fw);
        Logger log = new Logger("file", outputFile, fw, bw);
        log.outputFile = outputFile;*/
        Arena arena = Singleton.Instanta();
        BattleFactory battleMaker = new BattleFactory(arena);
        ArrayList<String> battleTypes = new ArrayList<>();
        battleTypes.add("vsNeutrel1");
        battleTypes.add("vsNeutrel2");
        battleTypes.add("vsTrainer");
        String chosenBattle = "";
        Type REVIEW_TYPE = new TypeToken<ArrayList<Antrenor>>() {}.getType();
        arena.antrenori = arena.readFile("TEST1.json", REVIEW_TYPE);
        //System.out.println(arena.antrenori);
        int index = 0, i = 0;
        while(index < 3){
            while(!chosenBattle.equals("vsTrainer")){
                String fileName = "output" + i + ".out";
                i++;
                File outputFile = new File(fileName);
                FileWriter fw = new FileWriter(outputFile.getName());
                BufferedWriter bw = new BufferedWriter(fw);
                Logger log = new Logger("file", outputFile, fw, bw);
                log.outputFile = outputFile;
                Random random = new Random();
                int randIndex = random.nextInt(battleTypes.size());
                chosenBattle = battleTypes.get(randIndex);
                Battle battle = battleMaker.beginBattle(chosenBattle);
                //System.out.println(arena.antrenori.get(0));
                battle.lupta(arena.antrenori.get(0).pokemoni[index], arena.antrenori.get(1).pokemoni[index], log);
            }
            chosenBattle = "";
            index++;
        }
        if(index == 3){
            String fileName = "FinalBattle.out";
            File outputFile = new File(fileName);
            FileWriter fw = new FileWriter(outputFile.getName());
            BufferedWriter bw = new BufferedWriter(fw);
            Logger log = new Logger("file", outputFile, fw, bw);
            log.outputFile = outputFile;
            Battle battle = battleMaker.beginBattle("vsTrainer");
            battle.lupta(arena.antrenori.get(0).bestPokemon(), arena.antrenori.get(1).bestPokemon(), log);
        }


    }

}
