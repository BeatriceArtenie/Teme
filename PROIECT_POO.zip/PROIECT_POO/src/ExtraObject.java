public class ExtraObject {
    public String nume;
    public int HP;
    public int attack;
    public int specialAttack;
    public int defense;
    public int specialDefense;

    public ExtraObject() {
    }

    public ExtraObject(String nume, int HP, int attack,
                       int specialAttack, int defense, int specialDefense) {
        this.nume = nume;
        this.HP = HP;
        this.attack = attack;
        this.specialAttack = specialAttack;
        this.defense = defense;
        this.specialDefense = specialDefense;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public String toString(){
        return "\nNume: " + nume + "\nHP:  " + HP + "\nAttack : " + attack +
                "\nSpecial Attack: " + specialAttack + "\nDefense: " + defense +
                "\nSpecial Defense: " + specialDefense;
    }
}
