import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class GenericBattle {
    public Arena arena;
    public ArrayList<Pokemon> neutrals;

    public GenericBattle(Arena arena, ArrayList<Pokemon> neutrals) {
        this.arena = arena;
        this.neutrals = neutrals;
    }

    public void genericBattle(Pokemon pokemon1, Pokemon pokemon2, Logger log) throws IOException {
        log.beginningOfBattle(pokemon1, pokemon2);
        Pokemon originalPokemon1 = new Pokemon(pokemon1.nume, pokemon1.HP, pokemon1.normalAttack,
                pokemon1.specialAttack, pokemon1.normalDefense, pokemon1.specialDefense, pokemon1.ability1,
                pokemon1.ability2, pokemon1.objects);
        Pokemon originalPokemon2 = new Pokemon(pokemon2.nume, pokemon2.HP, pokemon2.normalAttack, pokemon2.specialAttack,
                pokemon2.normalDefense, pokemon2.specialDefense, pokemon2.ability1, pokemon2.ability2,
                pokemon2.objects);
        Random random = new Random();
        if(pokemon1.objects != null && pokemon1.objects.size() > 0){
            int randIndex = random.nextInt(pokemon1.objects.size());
            ExtraObject randomObject = pokemon1.objects.get(randIndex);
            pokemon1.addObjectPerks(randomObject);
        }
        if(pokemon2.objects != null && !pokemon2.nume.equals("Neutrel1") && !pokemon2.nume.equals("Neutrel2")){
            int randIndex = random.nextInt(pokemon2.objects.size());
            ExtraObject randomObject = pokemon2.objects.get(randIndex);
            pokemon2.addObjectPerks(randomObject);
        }
        ArrayList<String> eventsPokemon1 = new ArrayList<>();
        eventsPokemon1.add("Attack");
        if(!pokemon1.nume.equals("Neutrel1") && !pokemon1.nume.equals("Neutrel2")){
            eventsPokemon1.add("Ability1");
            eventsPokemon1.add("Ability2");
        }
        ArrayList<String> eventsPokemon2 = new ArrayList<>();
        eventsPokemon2.add("Attack");
        if(!pokemon2.nume.equals("Neutrel1") && !pokemon2.nume.equals("Neutrel2")){
            eventsPokemon2.add("Ability1");
            eventsPokemon2.add("Ability2");
        }
        int p1CooldownTime1 = pokemon1.ability1.cooldown;
        int p1CooldownTime2 = pokemon1.ability2.cooldown;
        if(p1CooldownTime1 == 0 && p1CooldownTime2 == 0){
            p1CooldownTime1 = 100000;
            p1CooldownTime2 = 100000;
        }
        int p2CooldownTime1 = pokemon2.ability1.cooldown;
        int p2CooldownTime2 = pokemon2.ability2.cooldown;
        if(p2CooldownTime1 == 0 && p2CooldownTime2 == 0){
            p2CooldownTime1 = 100000;
            p2CooldownTime2 = 100000;
        }
        int p1Ability1WasUsed = 0;
        int p1Ability2WasUsed = 0;
        int p2Ability1WasUsed = 0;
        int p2Ability2WasUsed = 0;
        while(pokemon1.HP > 0 && pokemon2.HP > 0){
            int randIndex = random.nextInt(eventsPokemon1.size());
            String eventP1 = eventsPokemon1.get(randIndex);
            randIndex = random.nextInt(eventsPokemon2.size());
            String eventP2 = eventsPokemon2.get(randIndex);
            if(p1Ability1WasUsed == 1)
                pokemon1.ability1.cooldown--;
            if(p1Ability2WasUsed == 1)
                pokemon1.ability2.cooldown--;
            if(p2Ability1WasUsed == 1)
                pokemon2.ability1.cooldown--;
            if(p2Ability2WasUsed == 1)
                pokemon2.ability2.cooldown--;
            if(eventP1.equals("Attack")){
                if(pokemon1.normalAttack != -1) {
                    if (!pokemon1.isStun && !pokemon2.canDodge) {
                        log.attack("atac normal", pokemon1, p1CooldownTime1, p1CooldownTime2);
                        pokemon2.HP = pokemon2.HP - pokemon1.normalAttack + pokemon2.normalDefense;

                    if (!pokemon2.isStun && !pokemon1.canDodge) {
                        if (eventP2.equals("Attack")) {
                            if (pokemon2.normalAttack != -1) {
                                log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                            } else {
                                pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                                log.attack("atac special", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            }
                        } else if (eventP2.equals("Ability1")) {
                            if (pokemon2.ability1.cooldown == p2CooldownTime1) {
                                eventsPokemon2.remove("Ability1");
                                p2Ability1WasUsed = 1;
                                log.attack("Ability1", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                if (pokemon2.ability1.stun == 1)
                                    pokemon1.isStun = true;
                                if (pokemon2.ability1.dodge == 1)
                                    pokemon2.canDodge = true;
                                pokemon1.HP = pokemon1.HP - pokemon2.ability1.damage;
                            }
                        } else {
                            if (pokemon2.ability2.cooldown == p2CooldownTime2) {
                                eventsPokemon2.remove("Ability2");
                                p2Ability2WasUsed = 1;
                                log.attack("Ability2", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                if (pokemon2.ability2.stun == 1)
                                    pokemon1.isStun = true;
                                if (pokemon2.ability2.dodge == 1)
                                    pokemon2.canDodge = true;
                                pokemon1.HP = pokemon1.HP - pokemon2.ability2.damage;
                            }
                        }
                    }
                    else {
                        log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                        pokemon2.isStun = false;
                        pokemon1.canDodge = false;
                    }
                }
                    else {
                    log.attack("atac normal", pokemon1, p1CooldownTime1, p2CooldownTime2);
                    pokemon1.isStun = false;
                    pokemon2.canDodge = false;
                }
                }
                else{
                    if (!pokemon1.isStun && !pokemon2.canDodge) {
                        log.attack("atac special", pokemon1, p1CooldownTime1, p1CooldownTime2);
                        pokemon2.HP = pokemon2.HP - pokemon1.specialAttack + pokemon2.specialDefense;
                        if (!pokemon2.isStun && !pokemon1.canDodge) {
                            if (eventP2.equals("Attack")) {
                                if (pokemon2.normalAttack != -1) {
                                    log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                    pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                                } else {
                                    pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                                    log.attack("atac special", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                }
                            } else if (eventP2.equals("Ability1")) {
                                if (pokemon2.ability1.cooldown == p2CooldownTime1) {
                                    eventsPokemon2.remove("Ability1");
                                    p2Ability1WasUsed = 1;
                                    log.attack("Ability1", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                    if (pokemon2.ability1.stun == 1)
                                        pokemon1.isStun = true;
                                    if (pokemon2.ability1.dodge == 1)
                                        pokemon2.canDodge = true;
                                    pokemon1.HP = pokemon1.HP - pokemon2.ability1.damage;
                                }
                            } else {
                                if (pokemon2.ability2.cooldown == p2CooldownTime2) {
                                    eventsPokemon2.remove("Ability2");
                                    p2Ability2WasUsed = 1;
                                    log.attack("Ability2", pokemon2, p2CooldownTime1, p2CooldownTime2);
                                    if (pokemon2.ability2.stun == 1)
                                        pokemon1.isStun = true;
                                    if (pokemon2.ability2.dodge == 1)
                                        pokemon2.canDodge = true;
                                    pokemon1.HP = pokemon1.HP - pokemon2.ability2.damage;
                                }
                            }
                        }
                        else {
                            log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            pokemon2.isStun = false;
                            pokemon1.canDodge = false;
                        }
                    }
                    else {
                        log.attack("atac special", pokemon1, p1CooldownTime1, p2CooldownTime2);
                        pokemon1.isStun = false;
                        pokemon2.canDodge = false;
                    }
                }
            }
            else if(eventP1.equals("Ability1")) {
                if (!pokemon2.isStun && !pokemon1.canDodge) {
                    if (eventP2.equals("Attack")) {
                        if (pokemon2.normalAttack != -1) {
                            log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                        } else {
                            pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                            log.attack("atac special", pokemon2, p2CooldownTime1, p2CooldownTime2);
                        }
                    } else if (eventP2.equals("Ability1")) {
                        if (pokemon2.ability1.cooldown == p2CooldownTime1) {
                            eventsPokemon2.remove("Ability1");
                            p2Ability1WasUsed = 1;
                            log.attack("Ability1", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            if (pokemon2.ability1.stun == 1)
                                pokemon1.isStun = true;
                            if (pokemon2.ability1.dodge == 1)
                                pokemon2.canDodge = true;
                            pokemon1.HP = pokemon1.HP - pokemon2.ability1.damage;
                        }
                    } else {
                        if (pokemon2.ability2.cooldown == p2CooldownTime2) {
                            eventsPokemon2.remove("Ability2");
                            p2Ability2WasUsed = 1;
                            log.attack("Ability2", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            if (pokemon2.ability2.stun == 1)
                                pokemon1.isStun = true;
                            if (pokemon2.ability2.dodge == 1)
                                pokemon2.canDodge = true;
                            pokemon1.HP = pokemon1.HP - pokemon2.ability2.damage;
                        }
                    }
                } else {
                    log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                    pokemon2.isStun = false;
                    pokemon1.canDodge = false;
                }
                if(!pokemon1.isStun && !pokemon2.canDodge){
                    if(pokemon1.ability1.cooldown == p1CooldownTime1){
                        eventsPokemon1.remove("Ability1");
                        p1Ability1WasUsed = 1;
                        log.attack("Ability1", pokemon1, p1CooldownTime1, p1CooldownTime2);
                        if(pokemon1.ability1.stun == 1)
                            pokemon2.isStun = true;
                        if(pokemon1.ability1.dodge == 1)
                            pokemon1.canDodge = true;
                        pokemon2.HP = pokemon2.HP - pokemon1.ability1.damage;
                    }
                }
                else{
                    log.attack("Ability1", pokemon1, p1CooldownTime1, p1CooldownTime2);
                    pokemon1.isStun = false;
                    pokemon2.canDodge = false;
                }
            }
            else{
                if(!pokemon2.isStun && !pokemon1.canDodge){
                    if (eventP2.equals("Attack")) {
                        if (pokemon2.normalAttack != -1) {
                            log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                        } else {
                            pokemon1.HP = pokemon1.HP - pokemon2.normalAttack + pokemon1.normalDefense;
                            log.attack("atac special", pokemon2, p2CooldownTime1, p2CooldownTime2);
                        }
                    } else if (eventP2.equals("Ability1")) {
                        if (pokemon2.ability1.cooldown == p2CooldownTime1) {
                            eventsPokemon2.remove("Ability1");
                            p2Ability1WasUsed = 1;
                            log.attack("Ability1", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            if (pokemon2.ability1.stun == 1)
                                pokemon1.isStun = true;
                            if (pokemon2.ability1.dodge == 1)
                                pokemon2.canDodge = true;
                            pokemon1.HP = pokemon1.HP - pokemon2.ability1.damage;
                        }
                    } else {
                        if (pokemon2.ability2.cooldown == p2CooldownTime2) {
                            eventsPokemon2.remove("Ability2");
                            p2Ability2WasUsed = 1;
                            log.attack("Ability2", pokemon2, p2CooldownTime1, p2CooldownTime2);
                            if (pokemon2.ability2.stun == 1)
                                pokemon1.isStun = true;
                            if (pokemon2.ability2.dodge == 1)
                                pokemon2.canDodge = true;
                            pokemon1.HP = pokemon1.HP - pokemon2.ability2.damage;
                        }
                    }
                }
                else{
                    log.attack("atac normal", pokemon2, p2CooldownTime1, p2CooldownTime2);
                    pokemon2.isStun = false;
                    pokemon1.canDodge = false;
                }
                if(!pokemon1.isStun && !pokemon2.canDodge){
                    if(pokemon1.ability2.cooldown == p1CooldownTime2){
                        p1Ability2WasUsed = 1;
                        eventsPokemon1.remove("Ability2");
                        log.attack("Ability2", pokemon1, p1CooldownTime1, p1CooldownTime2);
                        if(pokemon1.ability2.stun == 1)
                            pokemon2.isStun = true;
                        if(pokemon1.ability2.dodge == 1)
                            pokemon1.canDodge = true;
                        pokemon2.HP = pokemon2.HP - pokemon1.ability2.damage;
                    }
                }
                else{
                    log.attack("atac normal", pokemon1, p1CooldownTime1, p1CooldownTime2);
                    pokemon1.isStun = false;
                    pokemon2.canDodge = false;
                }

            }
            if(pokemon1.ability1.cooldown == 0){
                pokemon1.ability1.cooldown = p1CooldownTime1;
                eventsPokemon1.add("Ability1");
                p1Ability1WasUsed = 0;
            }
            if(pokemon1.ability2.cooldown == 0){
                pokemon1.ability2.cooldown = p1CooldownTime2;
                eventsPokemon1.add("Ability2");
                p1Ability2WasUsed = 0;
            }
            if(pokemon2.ability1.cooldown == 0 && !pokemon2.nume.equals("Neutrel1") && !pokemon2.nume.equals("Neutrel2")){
                pokemon2.ability1.cooldown = p2CooldownTime1;
                eventsPokemon2.add("Ability1");
                p2Ability1WasUsed = 0;
            }
            if(pokemon2.ability2.cooldown == 0 && !pokemon2.nume.equals("Neutrel1") && !pokemon2.nume.equals("Neutrel2")){
                pokemon2.ability2.cooldown = p2CooldownTime2;
                eventsPokemon2.add("Ability2");
                p2Ability2WasUsed = 0;
            }
        }
        if(pokemon1.HP > 0){
            pokemon1.addPointsToWinner(pokemon2, originalPokemon1, originalPokemon2);
            log.showWinner(pokemon1);
        }
        else{
            pokemon2.addPointsToWinner(pokemon1, originalPokemon2, originalPokemon1);
            log.showWinner(pokemon2);
        }
    }
}
