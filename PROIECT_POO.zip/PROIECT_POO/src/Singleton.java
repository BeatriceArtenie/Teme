public class Singleton {
    private static Arena instantaUnica;

    public Singleton() {
    }

    public static Arena Instanta(){
        if(instantaUnica == null)
            instantaUnica = new Arena();
        return instantaUnica;
    }
}
