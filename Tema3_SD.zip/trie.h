/* ARTENIE Beatrice-Diana - 314CB */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define ALPH_T1 (93)
#define ALPH_T2 (57)

typedef struct {
    char *titlu;
    char *autor;
    int rating;
    int pag;
}TCarte; //structura ce contine informatiile unei carti

#define ALPH_SIZE (93)

typedef struct tnod1 {
    struct tnod1 *copii[ALPH_SIZE];
    TCarte info;
}TrieNod1, *T1;

typedef struct{
    int n;
}EsteFinal;
typedef struct tnod2 {
    struct tnod2 *copii[ALPH_SIZE];
    T1 carti_autor;
    int final;
}TrieNod2, *T2;

T1 InitTrie1(void);
T2 InitTrie2(void);

void add(T1 *trie1, T2 *trie2, TCarte carte, FILE *out);
void search1(T1 trie, char *titlu, FILE *out);
int search2(T2 trie, char *autor);
void list_author(T2 trie, char *autor, FILE *out);
void search_byAuthor(T2 trie, char *autor, char *titlu, FILE *out);
void afi_prefix_a(T1 trie, int depth, int *iter, FILE *out);
void search_prefix_b(T1 trie, char *prefix, FILE *out);
int find_pos(char c);
void afi_carti(T1 trie, int depth, FILE *out);
int aux_prefix(int i);
void afi_prefix_autor(T2 trie, int depth, int *iter, char nume[], char *prefix, FILE *out);
void search_prefix_a(T2 trie, char *prefix, FILE *out);
void search_by_author(T2 trie, char *autor, char *prefix, FILE *out);
int check_if_exists1(T1 trie, char *titlu, FILE *out);
T1 delete_T1(T1 trie, char *titlu, int level, FILE *out);
T2 delete_T2(T2 trie, char *autor, int level, FILE *out);
void delete_book(T1 *trie1, T2 *trie2, char *titlu, FILE *out);
void jobs(char *in, char *out);