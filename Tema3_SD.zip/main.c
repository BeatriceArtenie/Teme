/* ARTENIE Beatrice-Diana - 314CB */
#include "trie.h"

T1 InitTrie1(void) //functie de initializare a unui nod dintr-un trie T1
{
    T1 new_node = NULL; //new_node va fi nodul creat
    new_node = (T1)malloc(sizeof(TrieNod1)); //aloc memorie pentru nod
    //Verific daca am alocat cu succes memorie:
    if(!new_node){
        printf("Eroare alocare nod nou in T1\n");
        exit(1);
    }
    int c; 
    //initializez campurile informatiei unui nod cu NULL/0
    (new_node->info).titlu = NULL; 
    (new_node->info).autor = NULL;
    (new_node->info).pag = 0;
    (new_node->info).rating = 0;
    //parcurg vectorul corespunzator nodului si initializez elementele cu NULL
    for(c = 0; c < ALPH_T1; c++) 
        new_node->copii[c] = NULL;
    return new_node; //returnez nodul creat
}

T2 InitTrie2(void) //functie de initializare a unui nod dintr-un trie T2
{
    T2 new_node = NULL; //new_node va fi nodul creat
    new_node = (T2)malloc(sizeof(TrieNod2));//aloc memorie pentru nod
    //Verific daca am alocat cu succes memorie:
    if(!new_node){
        printf("Eroare alocare nod nou in T2.\n");
        exit(1);
    }
    int c;
    new_node->carti_autor = InitTrie1(); //initializez campul corespunzator informatiei cu ajutorul functiei de mai sus
    new_node->final = 0; //setez campul de verificare final la 0
    //parcurg vectorul corespunzator nodului si initializez elementele cu NULL
    for(c = 0; c < ALPH_T1; c++)
        new_node->copii[c] = NULL;
    return new_node; //returnez nodul creat
}

int find_pos(char c) //functie ce gaseste pozitia unui caracter in vectorul - informatie
{
    //Pentru a obtine pozitiile corecte pentru fiecare caracter, impart "alfabetul" dat in 4 parti
    char alph1[27] = "abcdefghijklmnopqrstuvwxyz";
    char alph2[27] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char alph3[11] = "0123456789";
    char alph4[7] = ".-'?! ";
    char *p1, *p2, *p3, *p4; //declar pointeri ce vor retine adresa caracterului intr-un segment de alfabet
    //Caut cu ajutorul functiei strchr caracterul primit in cele 4 stringuri
    p1 = strchr(alph1, c);
    p2 = strchr(alph2, c);
    p3 = strchr(alph3, c);
    p4 = strchr(alph4, c);
    if(p1 != NULL) //daca face parte din primul segment
        return (c - 'a');
    if(p2 != NULL) //daca face parte din al doilea segment
        return (c - 'A' + 26); 
    if(p3 != NULL) //daca face parte din al treilea segment
        return (c - '0' + 52);
    if(p4 != NULL) //daca face parte din al patrulea segment
        return ((c - '.') * (-1) + 62);
    return 0;
}
//Functie de cautare a unui autor intr-un trie T2
int search2(T2 trie, char *autor)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T2 t = trie; //declar un nou trie cu care voi parcurge trie-ul primit
    for(depth = 0; depth < strlen(autor); depth++){ //parcurg atatea noduri cate litere are cuvantul de inserat
        i = find_pos(autor[depth]); //gasesc pozitia la care se afla caracterul in vectorul corespunzator nodului curent
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla nicio litera
            return 0; //nu am gasit cuvantul; ies din functie
        }
        t = t->copii[i]; //trec la urmatorul nod
    }
    if(t != NULL){ //daca am gasit toate literele
        return 1; //am gasit cuvantul
    }
    return 0; //in caz contrar, ies din functie
}

//Functie de adaugare a unui nod in cele 2 trie-uri
void add(T1 *trie1, T2 *trie2, TCarte carte, FILE *out)
{
    int depth, i;
    //Declar cate o variabila pentru parcurgerea fiecarui trie
    T1 t1 = *trie1;
    T2 t2 = *trie2;
    char *titlu = malloc(51); //declar un pointer de tip char si il aloc dinamic pentru a retine titlul
    strcpy(titlu, carte.titlu); //copiez titlul din structura primita in variabila
    for(depth = 0; depth < strlen(titlu); depth++) //parcurg trie-ul
    {
        i = find_pos(titlu[depth]); //gasesc pozitia la care trebuie sa fac inserarea in vectorul nodului curent
        if(t1->copii[i] == NULL) //daca pozitia este libera
            t1->copii[i] = InitTrie1(); //initiez elementul
        t1 = t1->copii[i]; //ma mut la urmatoarea celula
    }
    //Plasez informatiile corespunzatoare ultimului nod in campurile corespunzatoare structurii
    (t1->info).titlu = strdup(carte.titlu);
    (t1->info).autor = strdup(carte.autor);
    (t1->info).rating = carte.rating;
    (t1->info).pag = carte.pag;
    //Caut autorul cartii in trie-ul T2
    int rez = search2(*trie2, carte.autor);
    char *autor = malloc(41); //declar un pointer de tip char si il aloc dinamic pentru a retine numele autorului
    strcpy(autor, carte.autor);
    if(!rez){ //Daca autorul nu se afla deja in trie-ul 2
        for(depth = 0; depth < strlen(autor); depth++)
        {
            int i = find_pos(autor[depth]); //gasesc pozitia la care trebuie sa fac inserarea in vectorul nodului curent
            if(t2->copii[i] == NULL) //daca pozitia este libera
                t2->copii[i] = InitTrie2(); //initiez elementul
            t2 = t2->copii[i]; //ma mut la urmatoarea celula
        }
        T1 trie_autor = t2->carti_autor; //Intr-o variabila de tip T1 retin arborele corespunzator unui autor (informatia nodului final)
        t2->final = 1; //marchez faptul ca am ajuns la final
        //Inserez la fel ca in arborele de tip T1
        for(i = 0; i < strlen(titlu); i++)
        {
            int j = find_pos(titlu[i]); 
            if(trie_autor->copii[j] == NULL)
                trie_autor->copii[j] = InitTrie1();
            trie_autor = trie_autor->copii[j];
        }
        (trie_autor->info).titlu = strdup(carte.titlu);
        (trie_autor->info).autor = strdup(carte.autor);
        (trie_autor->info).rating = carte.rating;
        (trie_autor->info).pag = carte.pag;
    }
    else{ //Daca autorul se afla deja in arborele T2
        for(depth = 0; depth < strlen(autor); depth++){ //Parcurg atatea noduri cate litere in numele autorului
            i = find_pos(autor[depth]); //gasesc pozitia caracterului curent in nodul curent
            t2 = t2->copii[i]; //merg la urmatorul nod
        }
        if(t2 != NULL){ //Daca am ajuns la ultimul nod
        //Repet inserarea intr-un arbore de tip T1
            T1 trie_autor = t2->carti_autor;
            for(i = 0; i < strlen(titlu); i++)
            {
                int j = find_pos(titlu[i]);
                if(trie_autor->copii[j] == NULL)
                    trie_autor->copii[j] = InitTrie1();
                trie_autor = trie_autor->copii[j];
            }
            (trie_autor->info).titlu = strdup(carte.titlu);
            (trie_autor->info).autor = strdup(carte.autor);
            (trie_autor->info).rating = carte.rating;
            (trie_autor->info).pag = carte.pag;
        }
    }
}

void search1(T1 trie, char *titlu, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T1 t = trie; //declar o variabila pentru parcurgerea arborelui
    for(depth = 0; depth < strlen(titlu); depth++){ //parcurg atatea noduri cate litere are titlul cartii
        i = find_pos(titlu[depth]); //calculez pozitia caracterului curent in vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Cartea %s nu exista in recomandarile tale.\n", titlu); //nu am gasit cartea cautata
            return; //ies din functie
        }
        t = t->copii[i]; //trec la nodul urmator
    }
    if(t != NULL && (t->info).titlu != NULL){ //daca am ajuns la finalul titlului cartii, iar nodul contine informatiile cartt (campul de titlu nu este nul)
        fprintf(out, "Informatii recomandare: %s, %s, %d, %d\n", (t->info).titlu, (t->info).autor, (t->info).rating, (t->info).pag);
        return; //scriu in fisier informatiile corespunzatoare si ies din functie
    }
    //Daca nu sunt indeplinite conditiile de mai sus, nu am gasit cartea; ies din functie
    fprintf(out, "Cartea %s nu exista in recomandarile tale.\n", titlu);
    return;
}

//Functie de afisare a cartilor dintr-un arbore de tip T1
void afi_carti(T1 trie, int depth, FILE *out)
{
    if ((trie->info).titlu != NULL) //daca nodul curent nu are campul de titlu al cartii nul
        fprintf(out, "%s\n", (trie->info).titlu); //scriu in fisier titlul cartii
  
    int i; //variabila de parcurgere a vectorului corespunzator unui nod
    for (i = 0; i < ALPH_T1; i++) //parcurg intreg vectorul (nodului curent)
    {
        if (trie->copii[i]) //daca pe pozitia i am gasit un caracter 
            afi_carti(trie->copii[i], depth + 1, out); //apelez functia pentru urmatorul copil, respectiv urmatorul caracter din titlu
    }
}

//Functie de afisare a cartilor corespunzatoare unui autor dintr-un arbore de tip T2
void list_author(T2 trie, char *autor, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T2 t = trie; //declar si initializez variabila cu care voi parcurge arborele
    for(depth = 0; depth < strlen(autor); depth++){ //cat timp nu am ajuns la finalul numelui autorului
        i = find_pos(autor[depth]); //calculez positia caracterului curent din vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Autorul %s nu face parte din recomandarile tale.\n", autor); //nu am gasit autorul; ies din functie
            return;
        }
        t = t->copii[i]; //trec la nodul urmator
    }
    if(t != NULL){ //daca am ajuns la finalul numelui autorului si inca ma aflu in arbore
        T1 carti = t->carti_autor; //intr-o variabila de tip T1 retin arborele de carti corespunzator autorului cerut
        afi_carti(carti, 0, out); //afisez cartile autorului
    } 
}

//Functie de cautare a unei carti in arborele corespunzator autorului din arborele de tip T2
void search_byAuthor(T2 trie, char *autor, char *titlu, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T2 t = trie; //declar si initializez variabila cu care voi parcurge arborele
    for(depth = 0; depth < strlen(autor); depth++){ //cat timp nu am ajuns la finalul numelui autorului
        i = find_pos(autor[depth]); //calculez positia caracterului curent din vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Autorul %s nu face parte din recomandarile tale.\n", autor); //nu am gasit autorul; ies din functie
            return;
        }
        t = t->copii[i]; //trec la nodul urmator
    }
    if(t != NULL){ //daca am ajuns la finalul numelui autorului si inca ma aflu in arbore
        T1 carti = t->carti_autor; //intr-o variabila de tip T1 retin arborele de carti corespunzator autorului cerut
        search1(carti, titlu, out); //caut cartea in arbore
    } 
}

//Functie care afiseaza toate cartile dintr-un arbore T1, cu un numar limitat de iteratii
void afi_prefix_a(T1 trie, int depth, int *iter, FILE *out)
{
    if ((trie->info).titlu != NULL){ //daca nodul curent nu are campul de titlu al informatiei nul
        fprintf(out, "%s\n", (trie->info).titlu); //scriu titlul in fisier
        (*iter)++; //maresc numarul de iteratii
    } 

    int i; //variabila de parcurgere a vectorului corespunzator unui nod
    for (i = 0; i < ALPH_T1; i++) //parcurg intreg vectorul (nodului curent)
    {
        if(*iter == 3) //daca am scris deja 3 titluri in fisier
            return; //ies din functie
        if (trie->copii[i]){ //daca pe pozitia i am gasit un caracter 
            afi_prefix_a(trie->copii[i], depth + 1, iter, out); //apelez functia pentru urmatorul copil, respectiv urmatorul caracter din titlu
        }
            
    }
}

//Functie care afiseaza toate cartile dintr-un arbore de tip T1 cu un prefix dat
void search_prefix_b(T1 trie, char *prefix, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T1 t = trie; //declar si initializez variabila cu care voi parcurge arborele
    for(depth = 0; depth < strlen(prefix); depth++){ //parcurg atatea noduri cate litere are prefixul
        i = find_pos(prefix[depth]); //calculez pozitia corespunzatoare caracterului curent in vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Nicio carte gasita.\n"); //nu exista carti cu prefixul dat
            return; //ies din functie
        }
        t = t->copii[i]; //trec la nodul urmator
    }
    if(t != NULL){ //daca am gasit toate literele prefixului in arbore si inca ma aflu in arbore
        int iter = 0; //declar variabila care va reprezenta numarul de iteratii ale functiei
        afi_prefix_a(t, 0, &iter, out); //afisez cartile din subarborele al carui radacina este nodul la care am ramas
        return; //ies din functie
    }
    //Daca nu este indeplinita conditia de mai sus, nu am gasit nicio carte al carei titlu incepe cu prefixul dat
    fprintf(out, "Nicio carte gasita.\n"); 
    return; //ies din functie
}

//Functie ce intoarce caracterul corespunzator unei pozitii in vectorul unui nod
int aux_prefix(int i) 
{ 
    if(i >= 0 && i <= 25) //daca se afla in primul segment
        return i + 'a'; //returnez caracterul corespunzator primului segment
    if(i >= 26 && i <= 51) //daca se afla in al doilea segment
        return i + 'A' - 26; //returnez caracterul corespunzator celui de-al doilea segment
    if(i >= 52 && i <= 61) //daca se afla in al treilea segment 
        return i + '0' - 52; //returnez caracterul corespunzator celui de-al treilea segment
    if(i == 62 || i == 63) //daca este '.' sau '-'
        return (-1)*i + '-' + 63; //returnez codul ascii al lui '.' sau '-'
    if(i == 69) //daca este '''
        return 39; //returnez codul ascii al lui '''
    if(i == 65) //daca este '?'
        return '?'; //returnez codul ascii al lui '?'
    if(i == 66 || i == 67) //daca este '!'
        return (-1)*i +'!' + 65;
    if(i == 76) //daca este ' ' 
        return ' '; //returnez codul ascii al lui ' '
    return 0;
}
//Functie ce afiseaza maxim 3 autori dintr-un arbore de tip T2 
void afi_prefix_autor(T2 trie, int depth, int *iter, char nume[], char *prefix, FILE *out)
{
    if(trie->final == 1){ //daca am ajuns la ultimul nod, respectiv ultimul caracter din nume
        nume[depth] = '\0'; //ultimul caracter al stringului construit este null - terminatorul
        fprintf(out, "%s%s\n", prefix, nume); //scriu in fisier numele complet
        (*iter)++; //maresc numarul de iteratii
    }
        
    for(int i = 0; i < ALPH_T1; i++) //parcurg intreg vectorul (nodului curent)
    {
        if(trie->copii[i]){  //daca pe pozitia i am gasit un caracter 
           
            nume[depth] = aux_prefix(i); //adaug caracterul la stringul in care construiesc numele autorului
            if(*iter == 3) //daca am scris deja 3 autori in fisier
                return; //ies din functie
            afi_prefix_autor(trie->copii[i], depth+1, iter, nume, prefix, out); //apelez functia pentru urmatorul nod
        }
            
    }
}

//Functie ce cauta si afiseaza autorii cu un anumit prefix intr-un arbore de tip T2
void search_prefix_a(T2 trie, char *prefix, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T2 t = trie; //declar si initializez variabila cu care voi parcurge arborele
    for(depth = 0; depth < strlen(prefix); depth++){ //parcurg atatea noduri cate litere are prefixul
        i = find_pos(prefix[depth]); //calculez pozitia corespunzatoare caracterului curent in vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Niciun autor gasit.\n"); //nu exista niciun autor cu prefixul dat
            return; //ies din functie
        }
        t = t->copii[i]; //trec la urmatorul nod
    }
    if(t != NULL){ //daca am gasit intregul prefix in arbore si inca ma aflu in arbore
        int iter = 0; //declar o variabila in care voi retine numarul de iteratii
        char nume[42]; //declar un string in care voi construi numele autorului (se adauga un caracter la fiecare apel al functiei)
        afi_prefix_autor(t, 0, &iter, nume, prefix, out); //afisez autorii
    } 
}

//Functie ce cauta toate cartile unui anumit autor, al caror titlu contine un anumit prefix
void search_by_author(T2 trie, char *autor, char *prefix, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T2 t = trie; //declar si initializez variabila cu care voi parcurge arborele
    for(depth = 0; depth < strlen(autor); depth++){ //parcurg atatea noduri cate litere are prefixul
        i = find_pos(autor[depth]); //calculez pozitia corespunzatoare caracterului curent in vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Autorul %s nu face parte din recomandarile tale.\n", autor); //autorul nu se afla in arbore
            return; //ies din functie
        }
        t = t->copii[i]; //trec la urmatorul nod
    }
    if(t != NULL){ //daca am gasit autorul
        T1 carti = t->carti_autor; //declar un arbore de tip T1 care retine arborele de carti corespunzator autorului dat
        search_prefix_b(carti, prefix, out); //afisez toate cartile cu prefixul dat
    }
}
//Functie ce verifica existenta unei carti intr-un arbore de tip T1
int check_if_exists1(T1 trie, char *titlu, FILE *out)
{
    int depth, i; //depth reprezinta treapta/nivelul la care ma aflu in trie, i reprezinta indexul caracterului curent in vector
    T1 t = trie; //declar si initializez variabila cu care voi parcurge arborele
    for(depth = 0; depth < strlen(titlu); depth++){ //parcurg atatea noduri cate litere are titlul dat
        i = find_pos(titlu[depth]); //calculez pozitia corespunzatoare caracterului curent in vector
        if(t->copii[i] == NULL){ //daca pe pozitia respectiva nu se afla niciun caracter
            fprintf(out, "Cartea %s nu exista in recomandarile tale.\n", titlu); //nu exista nicio carte cu titlul dat
            return 0; //ies din functie
        }
        t = t->copii[i]; //trec la nodul urmator
    }
    if(t != NULL && (t->info).titlu != NULL){ //daca am gasit cartea
        return 1; //returnez 1 = succes
    }
    fprintf(out, "Cartea %s nu exista in recomandarile tale.\n", titlu);
    return 0;
}

//Functie ce sterge o intrare din arborele T1
T1 delete_T1(T1 trie, char *titlu, int level, FILE *out)
{
    if(level == strlen(titlu)){ //daca am ajuns la finalul titlului 
        if(((trie)->info).titlu != NULL){ //daca nodul contine informatii despre carte
        //Resetez toate campurile corespunzatoare informatiei despre carte 
            ((trie)->info).titlu = NULL;
            ((trie)->info).autor = NULL;
            ((trie)->info).rating = 0;
            ((trie)->info).pag = 0;
        }
        T1 t = trie; //declar o variabila cu care voi parcurge urmatorul nod
        int prefix = 0; //declar o variabila care va retine daca un nod contine un caracter sau nu
        for(int i = 0; i < ALPH_T1; i++) //parcurg intregul vector al nodului
            if(t->copii[i]){ //daca exista un caracter 
                prefix = 1; //titlul cartii reprezinta un prefix pentru un alt titlu
                break; //ies din bucla for
            }
        if(!prefix) //daca nu este prefix
            free(trie); //eliberez nodul
        return trie; //returnez arborele 
    }
    int index = find_pos(titlu[level]); //calculez pozitia in vectorul unui nod al caracterului curent
    trie->copii[index] = delete_T1(trie->copii[index], titlu, level + 1, out); //apelez din nou functia pentru urmatorul nod
    T1 t = trie; //declar o variabila pentru a parcurge urmatorul nod al arborelui
    int prefix = 0; //declar o variabila care va retine daca un nod contine un caracter sau nu
    for(int i = 0; i < ALPH_T1; i++) //parcurg intreg vectorul nodului
        if(t->copii[i]){ //daca gasesc un caracter
            prefix = 1; //mai am carti in arbore
            break; //ies din bucla for
        }
    if(!prefix ){
        if((trie->info).titlu == NULL){ //daca nu mai am niciun titlu in arbore
            free(trie); //eliberez arborele
            trie = NULL; //ii atribul valoarea NULL
        }
    }
    return trie; //returnez arborele
}

//Functie ce sterge o  intrare dintr-un arbore de tip T2
T2 delete_T2(T2 trie, char *autor, int level, FILE *out)
{
    if(level == strlen(autor)){ //daca am ajuns la finalul numelui autorului
        if(trie->final == 1){ //Daca nodul reprezinta finalul unui nume
            free(trie->carti_autor); //eliberez arborele corespunzator autorului
            trie->carti_autor = NULL; //ii atribui acestui arbore valoarea NULL
            trie->final = 0; //Ca rezultat, nodul nu mai reprezinta finalul unui nume
        }
        T2 t = trie; //declar o variabila cu care voi parcurge urmatorul nod
        int prefix = 0; //declar o variabila care va retine daca un nod contine un caracter sau nu
        for(int i = 0; i < ALPH_T1; i++) //parcurg vectorul corespunzator nodului
            if(t->copii[i]){ //daca am gasit un caracter
                prefix = 1; //numele autorului gasit reprezinta prefixul altui nume
                break; //ies din bucla for
            }
        if(!prefix) //daca numele nu e prefix
            free(trie); //eliberez nodul
        return trie; //returnez arborele
    }
    int index = find_pos(autor[level]); //calculez pozitia din vectorului unui nod a caracterului curent
    trie->copii[index] = delete_T2(trie->copii[index], autor, level + 1, out); //apelez functia din nou pentru urmatorul nod, respectiv caracter
    //Similar cu stergerea din arborele de tip T1, verific daca mai am autori in arbore:
    T2 t = trie;
    int prefix = 0;
    for(int i = 0; i < ALPH_T1; i++)
        if(t->copii[i]){
            prefix = 1;
            break;
        }
    //Daca nu mai am, eliberez arborele si arborele ia valoarea NULL
    if(!prefix){
        if(t->final == 0){
            free(trie);
            trie = NULL;
        }
    }
    return trie;
}

//Functie ce sterge o carte din arbori de tip T1 si T2
void delete_book(T1 *trie1, T2 *trie2, char *titlu, FILE *out)
{
    char *autor; //variabila in care voi salva numele autorului in cazul in care am gasit cartea ce trebuie stearsa
    //Similar cu functii antecedente, parcurg arborele T1 pentru a cauta titlul cartii
    int depth, i; 
    T1 t = *trie1;
    for(depth = 0; depth < strlen(titlu); depth++){
        i = find_pos(titlu[depth]);
        t = t->copii[i];
    }
    if(t != NULL && (t->info).titlu != NULL){ //daca am gasit cartea, retin numele autorului
        autor = strdup((t->info).autor);
    }
    else //daca nu am gasit cartea, ies din functie
        return;
    T1 t1 = *trie1; //variabila cu care voi parcurge arborele T1
    T2 t2 = *trie2; //variabila cu care voi parcurge arborele T2
    *trie1 = delete_T1(t1, titlu, 0, out); //sterg cartea din arborele T1
    //Parcurg numele autorului in arborele de tip T2, pana cand t2 ajunge la ultimul caracter al jumelui
    for(depth = 0; depth < strlen(autor); depth++){
        i = find_pos(autor[depth]);
        t2 = t2->copii[i];
    }
    if(t2 != NULL){ //daca am ajuns la sfarsit
        t2->carti_autor = delete_T1(t2->carti_autor, titlu, 0, out); //sterg cartea cin arborele corespunzator autorului
    }
    if(t2->carti_autor == NULL) //daca autorul nu mai are carti in arborele sau
        *trie2 = delete_T2(*trie2, autor, 0, out); //sterg autorul
}

//Functie cu ajutorul careia interpretez comenzile din fisierul de intrare
void jobs(char *in, char *out)
{
    FILE *f_in, *f_out;
    f_in = fopen(in, "rt"); //deschid fisierul de intrare pentru citire
    f_out = fopen(out, "wt"); //deschid fisierul de iesire pentru scriere

    //Verific daca am deschis cu succes cele doua fisiere:
    if(f_in == NULL)
        printf("Nu am putut deschide f_in\n");
    if(f_out == NULL)
        printf("Nu am putut deschide f_out\n");

    size_t len = 0; //setez lungimea fisierului la 0
	char * line = NULL; //Initializez pointerul de linie cu NULL

    T1 trie1 = InitTrie1();
    T2 trie2 = InitTrie2();
    while (getline(&line, &len, f_in) != -1) {
        char *job = strtok(line, " "); //primul cuvant reprezinta actiunea ce trebuie efectuata
        if(strcmp(job, "add_book") == 0){ //daca trebuie sa adaug o carte in arbori
            char *titlu = strtok(NULL, ":"); //"titlu" va fi titlul cartii
            char *autor = strtok(NULL, ":"); //"autor" va indica numele autorului cartii
            char *rating = strtok(NULL, ":"); //"rating" va retine ratingul cartii, sub forma de string
            char *nrPag = strtok(NULL, ":"); //"nrPag" va retine numarul de pagini al cartii, sub forma de string

            //In locul ultimului caracter al ultimului cuvant ('\n') plasez null terminatorul:
            nrPag[strlen(nrPag) - 1] = '\0';
            int rt = atoi(rating); //convertesc ratingul la tipul intreg
            int nr_pg = atoi(nrPag); //convertesc numarul de pagini la tipul intreg
            TCarte Carte; //declar o variabila de tipul TCarte care va retine informatiile cartii
            //Completez campurile structurii cu informatia corespunzatoare:
            Carte.titlu = strdup(titlu); 
            Carte.autor = strdup(autor);
            Carte.rating = rt;
            Carte.pag = nr_pg;
            add(&trie1, &trie2, Carte, f_out); //adaug cartea in trie1 si trie2
        }
        if(strcmp(job, "search_book") == 0){ //daca trebuie sa caut o carte in trie1
            char *titlu = strtok(NULL, ":"); //"titlu" retine titlu cartii
            if(titlu[strlen(titlu) - 2] == '~'){ //daca al doilea "cuvant" este de fapt un prefix pentru un titlu
                titlu[strlen(titlu) - 2] = '\0'; //in locul caracterului '~' plasez null-terminatorul
                search_prefix_b(trie1, titlu, f_out); //caut cartile cu prefixul dat
            }
            else{ //daca al doilea cuvant nu este un prefix
                titlu[strlen(titlu) - 1] = '\0'; //in locul caracterului '\n' plasez null-terminatorul
                search1(trie1, titlu, f_out); //caut cartea in arborele trie1
            }
        }
        if(strcmp(job, "list_author") == 0){ //daca trebuie sa listez cartile unui autor
            char *autor = strtok(NULL, ":"); //"autor" retine autorul al carui carti trebuie sa le listez
            if(autor[strlen(autor) - 2] == '~'){ //daca lucrez cu prefixul unui autor
                autor[strlen(autor) - 2] = '\0';
                search_prefix_a(trie2, autor, f_out); //listez corespunzator autorilor cu prefixul dat
            }
            else{ //daca se da numele intreg al autorului
                autor[strlen(autor) - 1] = '\0';
                list_author(trie2, autor, f_out); //afisez cartile autorului respectiv
            }
            
        }
        if(strcmp(job, "search_by_author") == 0){ //daca trebuie sa caut un titlu in arborele unui autor
            char *autor = strtok(NULL, ":"); //primul cuvant este autorul in arborele caruia caut cartea
            if(autor[strlen(autor) - 2] == '~'){ //daca se da doar prefixul autorului
                autor[strlen(autor) - 2] = '\0'; 
                search_prefix_a(trie2, autor, f_out); //caut autorii cu prefixul corespunzator
            }
            else{ //daca se da intreg numele autorului
                char *titlu = strtok(NULL, ":"); //preiau titlu cartii pe care o caut
                if(titlu[strlen(titlu) - 2] == '~'){ //daca se da doar prefixul cartii
                    titlu[strlen(titlu) - 2] = '\0';
                    search_by_author(trie2, autor, titlu, f_out); //caut toate cartile cu prefixul dat
                }
                else{
                    titlu[strlen(titlu) - 1] = '\0';
                    search_byAuthor(trie2, autor, titlu, f_out); //in caz contrar, caut cartea cu titlul dat
                }
            }
        }
        if(strcmp(job, "delete_book") == 0){ //daca trebuie sa sterg o anumita carte atat din trie1, cat si din trie2
            char *titlu = strtok(NULL, ":"); //preiau titlul cartii pe care trebuie sa o sterg
            titlu[strlen(titlu) - 1] = '\0';
            int exists = check_if_exists1(trie1, titlu, f_out); //Verifica daca exista cartea data in trie1
            if(exists) //daca am gasit cartea data in trie1
                delete_book(&trie1, &trie2, titlu, f_out); //sterg cartea din cei doi arbori
        }
    }

    //Inchid fisierele de intrare si iesire:
    fclose(f_in); //inchid fisierulo de intrare
    fclose(f_out); //inchid fisierul de iesire
}
int main(int argc, char **argv)
{
	jobs(argv[1], argv[2]); //apelez functia de prelucrare a datelor de intrare
  	return 0;
}
